# jquery-newsticker
jQuery Breaking News Ticker- A powerful, flexible, fast, easy to use news ticker
 
