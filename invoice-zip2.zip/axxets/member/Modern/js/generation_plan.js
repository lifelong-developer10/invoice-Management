
$(document).ready(function(){
        $("#level1").hide();
        $("#level2").hide();
        $("#level3").hide();
        $("#level4").hide();
        $("#level5").hide();
        $("#level6").hide();
        $("#level7").hide();
        $("#level8").hide();
        $("#level9").hide();
        $("#level10").hide();
    $('#SelctLevel').on('change', function() {
     
      if ( this.value == '1')
      {
        
        $("#level1").show();
        $("#level2").hide();
        $("#level3").hide();
        $("#level4").hide();
        $("#level5").hide();
        $("#level6").hide();
        $("#level7").hide();
        $("#level8").hide();
        $("#level9").hide();
       $("#level10").hide();
        
      }
      else if(this.value=='2')
      {

        $("#level2").show();
        $("#level1").hide();
        $("#level3").hide();
        $("#level4").hide();
        $("#level5").hide();
        $("#level6").hide();
        $("#level7").hide();
        $("#level8").hide();
        $("#level9").hide();
$("#level10").hide();

      }
       else if(this.value=='3')
      {
        $("#level3").show();
        $("#level1").hide();
        $("#level2").hide();
        $("#level4").hide();
        $("#level5").hide();
        $("#level6").hide();
        $("#level7").hide();
        $("#level8").hide();
        $("#level9").hide();
$("#level10").hide();

      } 
      else if(this.value=='4')
      {
        $("#level4").show();
        $("#level1").hide();
        $("#level2").hide();
        $("#level3").hide();
        $("#level5").hide();
        $("#level6").hide();
        $("#level7").hide();
        $("#level8").hide();
        $("#level9").hide();
$("#level10").hide();
      }
      else if(this.value=='5')
      {
        $("#level5").show();
        $("#level1").hide();
        $("#level2").hide();
        $("#level3").hide();
        $("#level4").hide();
        $("#level6").hide();
        $("#level7").hide();
        $("#level8").hide();
        $("#level9").hide();
$("#level10").hide();

      } 
      else if(this.value=='6')
      {
        $("#level6").show();
        $("#level1").hide();
        $("#level2").hide();
        $("#level3").hide();
        $("#level4").hide();
        $("#level5").hide();
        $("#level7").hide();
        $("#level8").hide();
        $("#level9").hide();
$("#level10").hide();

      }
      else if(this.value=='7')
      {
        $("#level7").show();
        $("#level1").hide();
        $("#level2").hide();
        $("#level3").hide();
        $("#level4").hide();
        $("#level5").hide();
        $("#level6").hide();
        $("#level8").hide();
        $("#level9").hide();
$("#level10").hide();

      }
      else if(this.value=='8')
      {
        $("#level8").show();
        $("#level1").hide();
        $("#level2").hide();
        $("#level3").hide();
        $("#level4").hide();
        $("#level5").hide();
        $("#level6").hide();
        $("#level7").hide();
        $("#level9").hide();
$("#level10").hide();

      }
      else if(this.value=='9')
      {
        $("#level9").show();
        $("#level1").hide();
        $("#level2").hide();
        $("#level3").hide();
        $("#level4").hide();
        $("#level5").hide();
        $("#level6").hide();
        $("#level7").hide();
        $("#level8").hide();
        $("#level10").hide();


      }
      else if(this.value=='10')
      {
        $("#level10").show();
        $("#level1").hide();
        $("#level2").hide();
        $("#level3").hide();
        $("#level4").hide();
        $("#level5").hide();
        $("#level6").hide();
        $("#level7").hide();
        $("#level8").hide();
        $("#level9").hide();


      }



    });
});
