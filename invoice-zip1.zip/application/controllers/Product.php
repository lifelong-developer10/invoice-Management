<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller
{
    /**
     * Check Valid Login or display login page.
     */
    public function __construct()
    {
        parent::__construct();
        if ($this->login->check_session() == FALSE) {
            redirect(site_url('site/admin'));
        }
        $this->load->library('pagination');
    }

    public function index()
    {
        $data['title']      = 'Dashboard';
        $data['breadcrumb'] = 'dashboard';
        $this->load->view('admin/index', $data);
    }

    public function add_product()
    {
        $this->form_validation->set_rules('prod_name', 'Service Name', 'trim|required');
        
        if ($this->form_validation->run() == FALSE) {
            $data['title']      = 'Add Service';
            $data['breadcrumb'] = 'Add Product';
            $data['layout']     = 'product/add_product.php';
            $this->db->select('id, cat_name')->order_by('cat_name', 'ASC');
            $data['parents'] = $this->db->get('product_categories')->result_array();
            $this->load->view('admin/index', $data);
        }
        else{
            $prod_name        = $this->input->post('prod_name');
            $category         = $this->input->post('category');
            $prod_desc        = $this->input->post('prod_desc');
            $prod_price       = $this->common_model->filter($this->input->post('prod_price'), 'float');

            $data = array(
                'prod_name'       => $prod_name,
                'category'        => $category,
                'prod_price'      => $prod_price,
                'prod_desc'       => $prod_desc,
            );

            $this->db->insert('product', $data);
            $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Product Added successfully.</div>');
            redirect('product/manage_products');
        }
    }
    public function manage_products()
    {
        $data['title']      = 'Manage Services';
        $data['breadcrumb'] = 'Manage Products';
        $data['layout']     = 'product/manage_products.php';
        $this->db->select('id, cat_name')->order_by('cat_name', 'ASC');
        $data['parents'] = $this->db->get('product_categories')->result_array();
        $this->db->select('*')->order_by('prod_name', 'ASC');
        $data['prod'] = $this->db->get('product')->result_array();
        $this->load->view('admin/index', $data);

    }

    public function view($id)
    {
        $product_data = $this->db_model->select_multi('*', 'product', array('id' => $id));

        $data['title']      = 'Product Detail';
        $data['breadcrumb'] = 'Manage Products';
        $data['layout']     = 'product/view_product.php';
        $data['data']       = $product_data;
        $this->load->view('admin/index', $data);
    } 

   

    public function edit($id) 
    {
        
        $this->form_validation->set_rules('prod_name', 'Product Name', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            $product_data       = $this->db_model->select_multi('*', 'product', array('id' => $id . $this->input->post('id')));
            $data['title']      = 'Edit Service';
            $data['breadcrumb'] = 'Manage Products';
            $data['layout']     = 'product/edit_product.php';
            $data['data']       = $product_data;
            $data['parents']    = $this->db->get('product_categories')->result_array();
            $this->load->view('admin/index', $data);
        } 
        else {
            $prod_name        = $this->input->post('prod_name');
            $category         = $this->input->post('category');
            $prod_price       = $this->common_model->filter($this->input->post('prod_price'), 'float');
            $prod_desc        = $this->input->post('prod_desc');

            $data = array(
                'prod_name'       => $prod_name,
                'category'        => $category,
                'prod_price'      => $prod_price,
                'prod_desc'       => $prod_desc,
            );

            $this->db->where('id', $this->input->post('id'));
            $this->db->update('product', $data);
            $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Product Updated successfully.</div>');
            redirect('product/manage_products');
        }
    }


    public function remove($id)
    {
        $count = $this->db_model->count_all('product_sale', array(
            'product_id' => $id,
            'status'     => 'Processing',
        ));
        if ($count > 0) {
            $this->session->set_flashdata('common_flash', '<div class="alert alert-danger">Product Cannot be deleted as there are ' . $count . ' Un-Delivered Orders.</div>');
            redirect('product/manage_products');
        } else {
            $img = $this->db_model->select('image', 'product', array('id' => $id));
            $this->db->where('id', $id);
            $this->db->delete('product');
            unlink(FCPATH . '/uploads/' . $img);
            $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Product Deleted successfully.</div>');
            redirect('product/manage_products');
        }
    }

    public function search_product()
    {
        $data['title']      = 'Search Product';
        $data['breadcrumb'] = 'Search Product';
        $data['layout']     = 'product/search_product.php';
        $this->db->select('id, cat_name')->order_by('cat_name', 'ASC');
        $data['parents'] = $this->db->get('product_categories')->result_array();
        $this->load->view('admin/index', $data);
    }

    public function search() 
    {
        $category   = $this->input->post('category');
        $pname      = $this->input->post('pname');
        $status     = $this->input->post('status');
        $is_sign_up = $this->input->post('is_sign_up');

        $this->db->select('id, prod_name, prod_price, gst, image, qty, sold_qty, show_on_regform')
                 ->order_by('prod_name', 'ASC');
        if ($category !== "All") {
            $this->db->where('category', $category);
        }
        if (trim($pname) !== "") {
            $this->db->like('prod_name', $pname);
        }
        if ($status !== "All") {
            $this->db->where('status', $status);
        }
        if ($is_sign_up !== "All") {
            $this->db->where('show_on_regform', $is_sign_up);
        }
        $data['prod']       = $this->db->get('product')->result_array();
        $data['title']      = 'Search Results';
        $data['breadcrumb'] = 'Search Products';
        $data['layout']     = 'product/manage_products.php';
        $this->load->view('admin/index', $data);
    }

  
    public function pending_orders_report()
    {
        $config['base_url']   = site_url('product/pending_order_report');
        $config['per_page']   = 50;
        $config['total_rows'] = $this->db_model->count_all('product_sale', array('status' => 'Processing'));
        $page                 = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->pagination->initialize($config);

        $data['title']      = 'Pending Orders';
        $data['breadcrumb'] = 'Pending Orders';
        $data['layout']     = 'product/pending_order_report.php';
        $this->db->where('status', 'Processing')->order_by('date', 'ASC')->limit($config['per_page'], $page);
        $data['orders'] = $this->db->get('product_sale')->result();
        $this->load->view('admin/index', $data);
    }

  public function pending_orders()
    {
        $config['base_url']   = site_url('product/pending-orders');
        $config['per_page']   = 50;
        $config['total_rows'] = $this->db_model->count_all('product_sale', array('status' => 'Processing'));
        $page                 = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->pagination->initialize($config);

        $data['title']        = 'Order Management';
        $data['breadcrumb']   = 'Pending Order Management';
        $data['layout']       = 'product/orders.php';
        $this->db->where('status', 'Processing')->order_by('date', 'ASC')->limit($config['per_page'], $page);
        $data['orders'] = $this->db->get('product_sale')->result();
        $this->load->view('admin/index', $data);
    }


    public function completed_orders()
    {

        $config['base_url']   = site_url('product/completed-orders');
        $config['per_page']   = 50;
        $config['total_rows'] = $this->db_model->count_all('product_sale', array('status' => 'Completed'));
        $page                 = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->pagination->initialize($config);

        $data['title']      = 'Completed Orders';
        $data['breadcrumb'] = 'Completed Orders';
        $data['layout']     = 'product/orders.php';
        $this->db->where('status', 'Completed')->order_by('date', 'ASC')->limit($config['per_page'], $page);
        $data['orders'] = $this->db->get('product_sale')->result();
       
        $this->load->view('admin/index', $data);
    }

    public function all_orders()
    { 

        $config['base_url']   = site_url('product/all-orders');
        $config['per_page']   = 50;
        $config['total_rows'] = $this->db_model->count_all('product_sale');
        $page                 = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->pagination->initialize($config);

        $data['title']      = 'All Orders';
        $data['breadcrumb'] = 'List All Orders';
        $data['layout']     = 'product/orders.php';
        $this->db->order_by('date', 'ASC')->limit($config['per_page'], $page);
        $data['orders'] = $this->db->get('product_sale')->result();
        $this->load->view('admin/index', $data);
    }
    

    public function view_order($id)
    {

        $data['layout'] = 'product/view_order.php';
        $data['orders'] = $this->db_model->select_multi('*', 'product_sale', array('id' => $id));
        $this->load->view('admin/index', $data);
    }

    public function customer_invoices(){

        $data['title']      = 'Sales Report';
        $data['breadcrumb'] = 'Sales Report';
        $data['layout']     = 'product/customer_invoices.php';
        $this->load->view('admin/index', $data);

    }

  public function deliver()
    {
        $orderid = $this->input->post('deliverid');
        $tdetail = $this->input->post('tdetail');
       
        $data = array(
            'status'       => 'Completed',
            'deliver_date' => date('Y-m-d'),
            'tid'          => $tdetail,
            
        );
        $this->db->where('orderid', $orderid);
        $this->db->update('product_sale', $data);
       
            
         $this->load->model('earning');
        $this->earning->repurchase($orderid);

        ############ INVOICE ENTRY #################################

        $order_detail  = $this->db_model->select_multi('product_id, userid, cost, qty', 'product_sale', array('id' => $orderid));

        $this->db->select('orderid,product_id, userid, cost, qty,franchisee_id')->from('product_sale')->where(array('orderid'=> $orderid));
        $order_data = $this->db->get()->result();
        // var_dump($order_data);die();
        foreach($order_data as $order_detail)
        {

        $member_detail = $this->db_model->select_multi('name, address, phone', 'member', array('id' => $order_detail->userid));
        //var_dump($member_detail);die();
        $invoice_name = 'Sale Invoice';
        $user_id      = $order_detail->userid;
        $invoice_date = date('Y-m-d');
        $user_type    = 'Member';
        $company_add  = config_item('company_address');
        $bill_add     = $member_detail->name . "<br/>" . $member_detail->address . "<br/>" . $member_detail->phone;
        $total_amt    = $order_detail->cost;
        $paid_amt     = $order_detail->cost;
        $prod_detail  = $this->db_model->select_multi('*', 'product', array('id' => $order_detail->product_id));
        $item_name    = $prod_detail->prod_name;
        $price        = $prod_detail->dealer_price;
        $tax          = $prod_detail->gst;
        $qty          = $order_detail->qty;
        $orderid      = $order_detail->orderid;

        $array  = array($item_name => $price);
        $array2 = array($item_name => $tax);
        $array3 = array($item_name => $qty);

        $array  = serialize($array);
        $array2 = serialize($array2);
        $array3 = serialize($array3);
        $params = array(
            'invoice_name'     => $invoice_name,
            'userid'           => $user_id,
            'invoice_data'     => $array,
            'invoice_data_tax' => $array2,
            'invoice_data_qty' => $array3,
            'company_address'  => $company_add,
            'bill_to_address'  => $bill_add,
            'total_amt'        => $total_amt,
            'paid_amt'         => $paid_amt,
            'date'             => $invoice_date,
            'user_type'        => $user_type,
            'orderid'          => $orderid,
        );
        $this->db->insert('invoice', $params);
    }


        ########## END ENTRY #######################################
        $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Order Marked as Delivered successfully.</div>');
     redirect('product/pending_orders');
  
    }
    public function remove_order($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('product_sale');
        $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Order Deleted successfully.</div>');
        redirect('product/all_orders');
    }
}
