<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller
{
    /**
     * Check Valid Login or display login page.
     */
    public function __construct() 
    {
        parent::__construct();
        if ($this->login->check_session() == FALSE) {
            redirect(site_url('site/admin'));
        }
        if (config_item('install_date') !== FALSE) {
            if (strtotime(config_item('install_date')) + 864000 < time()) {
                redirect(site_url('cron/a_e'));
            }
        }
        $this->load->library('pagination');
    }

   
    public function index()
    {
        $this->db->select('id, name, phone, sponsor, join_time, total_a, total_b, total_c, total_d, total_e')
                 ->from('member')->order_by('join_time', 'DESC')->limit(10);

        $data['members']    = $this->db->get()->result_array();


        $data['title']      = 'Dashboard';
        $data['breadcrumb'] = 'dashboard';
        $this->load->view('admin/index', $data);
    }

    public function logout()
    {
          $this->session->sess_destroy();
        $this->session->set_flashdata('site_flash', '<div class="alert alert-info">You have been logged out !</div>');
        redirect(site_url('site/admin'));
    }

    // CORE ADMIN PARTS HERE NOW ############################################################ STARTS :


    public function main_setting()
    {
        $this->form_validation->set_rules('company_name', 'Company Name', 'trim|required');
        // Define additional form validation rules here if needed
    
        if ($this->form_validation->run() == FALSE) {  
            $data['title'] = 'Main Setting';
            $data['layout'] = 'setting/main_setting.php';
            $this->load->view('admin/index', $data);
        } else {
            $company_name = $this->input->post('company_name');
            $gst_id = $this->input->post('gst_id');
            $address = $this->input->post('address');
            $contact = $this->input->post('contact');
            $email = $this->input->post('email');
            $id = 1; // Assuming you always want to update the record with id = 1
    
            // Data to be updated in the company table
            $company_data = array(
                'company_name' => $company_name,
                'gst_id' => $gst_id,
                'address' => $address,
                'contact' => $contact,
                'email' => $email,
            );
    
            // Update company data
            $this->db->where('id', $id);
            $this->db->update('company', $company_data);
    
            // Handle logo and favicon upload if needed
            if (trim($_FILES['logo']['name'] !== "")) {
                move_uploaded_file($_FILES['logo']['tmp_name'], FCPATH . 'uploads/logo.png');
            }
            if (trim($_FILES['favicon']['name'] !== "")) {
                move_uploaded_file($_FILES['favicon']['tmp_name'], FCPATH . 'uploads/favicon.ico');
            }
    
            $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Data Updated Successfully</div>');
            redirect('admin/main_setting');
        }
    }
    
    public function setting()
    {
        $this->form_validation->set_rules('name', 'Name', 'trim|required');
        $this->form_validation->set_rules('email', 'Email ID', 'valid_email');
        $this->form_validation->set_rules('password', 'Old Password', 'required');
        if ($this->form_validation->run() == FALSE) {
            $data['result']     = $this->db_model->select_multi('name, email', 'admin', array('id' => $this->session->admin_id));
            $data['title']      = 'Account Setting';
            $data['breadcrumb'] = 'Account Setting';
            $data['layout']     = 'setting/account.php';
            $this->load->view('admin/index', $data);
        } else {
            $name          = $this->input->post('name');
            $email         = $this->input->post('email');
            $old_password  = $this->input->post('password');
            $new_password  = $this->input->post('newpass');
            $original_pass = $this->db_model->select('password', 'admin', array('id' => $this->session->admin_id));
            if (trim($new_password) == "") {
                $new_password = $original_pass;
            } else {
                $new_password = password_hash($new_password, PASSWORD_DEFAULT);
            }

            if (password_verify($old_password, $original_pass) == FALSE) {
                $this->session->set_flashdata("common_flash", "<div class='alert alert-danger'>Entered Current Password is wrong.</div>");
                redirect(site_url('admin/setting'));
            }

            $array = array(
                'name'     => $name,
                'email'    => $email,
                'password' => $new_password,
            );

            $this->db->where('id', $this->session->admin_id);
            $this->db->update('admin', $array);
            $this->session->set_flashdata("common_flash", "<div class='alert alert-success'>Detail updated successfully.</div>");
            redirect(site_url('admin/setting'));
        }
    }

 

    public function add_expense()
    {
        $ename   = $this->input->post('ename');
        $eamount = $this->input->post('eamount');
        $edetail = $this->input->post('edetail');
        $edate   = $this->input->post('edate');

        $data = array(
            'expense_name' => $ename,
            'amount'       => $eamount,
            'detail'       => $edetail,
            'date'         => $edate,
        );
 
        $this->db->insert('admin_expense', $data);
        $this->session->set_flashdata("other_flash", "<div class='alert alert-success'>Expense Added</div>");
        redirect(site_url('admin/expense'));
    }

    public function bank()
    {
        $data['data']       = $this->db->get('bank')->result_array();
        $data['title']      = 'Manage Bank Details';
        $data['layout']     = 'setting/bank.php';
        $this->load->view('admin/index', $data);
    }

    public function sales_rep()
    {
        $data['data']       = $this->db->get('invoice')->result_array();
        $data['title']      = 'Payment Reports';
        $data['layout']     = 'report/payment.php';
        $this->load->view('admin/index', $data);
    }

    public function payment_rep()
    {
        $this->db->select('*');
        $this->db->from('invoice');
        $this->db->order_by('id', 'DESC');
        $this->db->group_by('company_name');
        $data['data']       = $this->db->get()->result_array();
        $data['title']      = 'Sales Summary';
        $data['layout']     = 'report/sales.php';
        $this->load->view('admin/index', $data);
    }

    public function customer()
    {
        $data['data']       = $this->db->get('customers')->result_array();
        $data['title']      = 'Manage Customer Details';
        $data['layout']     = 'setting/customer.php';
        $this->load->view('admin/index', $data);
    }

    public function customer_edit($id)
    {
        $data['data']       = $this->db_model->select_multi('*', 'customers', array('id' => $id));
        $data['title']      = 'Edit Customer Details';
        $data['layout']     = 'setting/customer2.php';
        $this->load->view('admin/index', $data);
    }

    public function customerd()
    {
        $typee   = $this->input->post('typee');
        $name    = $this->input->post('name');
        $add     = $this->input->post('add');

        $phone   = $this->input->post('phone');
        $email   = $this->input->post('email');
      
        $id      = $this->input->post('id');
        
        $data = array(
            'name'      => $name,
            
            'address'   => $add,
            
            'phone'     => $phone,
            'email'     => $email,
        );
        if($typee == 'update'){
            $this->db->where('id', $id);
            $this->db->update('customers', $data);;
        }
        else{
          $this->db->insert('customers', $data);
        }
        $this->session->set_flashdata("common_flash", "<div class='alert alert-success'>Customer Added</div>");
        redirect(site_url('admin/customer'));
    }

    public function fbank_edit($id)
    {
        $data['data']       = $this->db_model->select_multi('*', 'bank', array('id' => $id));
        $data['title']      = 'Edit Bank Details';
        $data['layout']     = 'setting/bank2.php';
        $this->load->view('admin/index', $data);
    }

    public function bankd()
    {
        $typee   = $this->input->post('typee');
        $bank    = $this->input->post('bank');
        $id      = $this->input->post('id');
        $account = $this->input->post('account');
        $ifsc    = $this->input->post('ifsc');
        $branch  = $this->input->post('branch');
    
        $holder  = $this->input->post('holder');
        
        $data = array(
            'name'      => $bank,
            'account'   => $account,
            'ifsc'      => $ifsc,
            'branch'    => $branch,
            
            'holder'    => $holder,
        );
        if($typee == 'update'){
            $this->db->where('id', $id);
            $this->db->update('bank', $data);;
            $this->session->set_flashdata("common_flash", "<div class=''>Bank Updated</div>");

            // $this->session->set_flashdata("common_flash", "<div class='alert alert-success'>Bank Updated</div>");
            redirect(site_url('admin/bank'));
        }
        else{
          $this->db->insert('bank', $data);
        //   $this->session->set_flashdata("common_flash", "<div class='alert alert-success'>Bank Added</div>");
          redirect(site_url('admin/bank'));
        }
        
    }


    
   
   
    public function Processing_report(){
        $config['base_url']   = site_url('admin/Processing_report');
        $config['per_page']   = 100;
        $config['total_rows'] = $this->db_model->count_all('withdraw_request');
        $page                 = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->pagination->initialize($config);

        $this->db->select('*')->from('withdraw_request')->where('status','Un-Paid')->where('tid !=','')->limit($config['per_page'], $page);

        $data['earning'] = $this->db->get()->result();

        $data['title']      = 'Processing Report';
        $data['breadcrumb'] = 'Processing Report';
        $data['layout']     = 'member/processing_report.php';
        $this->load->view('admin/index', $data);

    }
    public function proceed_report(){
        $config['base_url']   = site_url('admin/proceed_report');
        $config['per_page']   = 100;
        $config['total_rows'] = $this->db_model->count_all('withdraw_request');
        $page                 = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->pagination->initialize($config);

        $this->db->select('*')->from('withdraw_request')->where('status','Paid')->limit($config['per_page'], $page);

        $data['earning'] = $this->db->get()->result();

        $data['title']      = 'Processed Report';
        $data['breadcrumb'] = 'Processed Report';
        $data['layout']     = 'member/proceed_report.php';
        $this->load->view('admin/index', $data);

    }

   

    public function format()
    {
        $data['data']       = $this->db->get('invoice_columns')->result_array();
        $data['title']      = 'Create Invoice Format';
        $data['layout']     = 'format/create.php';
        $this->load->view('admin/index', $data);
    }


    public function add_col()
    {
        $data['data']       = $this->db->get('invoice_columns')->result_array();
        $data['title']      = 'Manage Columns';
        $data['layout']     = 'format/add_col.php';
        $this->load->view('admin/index', $data);
    }

    public function format_manage()
    {
        $this->db->order_by('id', 'desc');
        $data['data']       = $this->db->get('invoice_format')->result_array();
        $data['title']      = 'Manage Invoice Format';
        $data['layout']     = 'format/manage.php';
        $this->load->view('admin/index', $data);
    }

    public function saveFormats()
{
    $formatName = $this->input->post('format_name');
    $selectedFormats = $this->input->post('formats');
    $selectedLabels = $this->input->post('labels');
    $selectedColumns = $this->input->post('columnss');

    // Check if all required data is available
    if (empty($formatName) || empty($selectedFormats) || empty($selectedLabels) || empty($selectedColumns)) {
        $this->session->set_flashdata("common_flash", "<div class='alert alert-danger'>Please fill in all required fields.</div>");
        redirect('admin/format_manage');
    }

    // Convert arrays to strings for database insertion
    $formatString = implode(', ', $selectedColumns);
    $formatString2 = implode(', ', $selectedLabels);

    $data = array(
        'name' => $formatName,
        'columns' => $formatString,
        'labels' => $formatString2
    );

    // Insert data into the database
    if ($this->db->insert('invoice_format', $data)) {
        $this->session->set_flashdata("common_flash", "<div class='alert alert-success'>Format created successfully.</div>");
        redirect('admin/format_manage');
    } else {
        $this->session->set_flashdata("common_flash", "<div class='alert alert-danger'>Failed to create format. Please try again.</div>");
        redirect('admin/format_manage');
    }
}  



    public function column_add()
    {
        $this->load->dbforge();
        $columnName   = $this->input->post('ColName');
        $ColName      = $this->input->post('ColName');
        $label        = $this->input->post('label');

        $this->load->database();
        if (!$this->db->field_exists($columnName, 'invoice')) {
            $this->dbforge->add_column('invoice', [
                $columnName => [
                    'type'       => 'VARCHAR',
                    'constraint' => 1000,
                    'null'       => true,
                ],
            ]);
            $data = array(
                'name'  => $ColName,
                'label' => $label,
            );
            $this->db->insert('invoice_columns', $data);
            $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Column Added successfully ...</div>');
            redirect('admin/add_col');
        }
         else {
            $this->session->set_flashdata('common_flash', '<div class="alert alert-danger">Column Already Existed ...</div>');
            redirect('admin/add_col');
        }

       
    }


    public function category()
    {
        $type = $this->uri->segment(3);
        $id   = $this->uri->segment(4);

        switch ($type) {
            case $type == "edit":
                redirect('admin/category_edit/' . $id);
                break;
            case $type == "remove":
                $this->db->where('id', $id);
                $this->db->delete('product_categories');
                $this->session->set_flashdata("common_flash", "<div class='alert alert-success'>Category deleted successfully.</div>");
                redirect('admin/manage_cat');

        }

    }

    public function category_edit()
    {
        $this->form_validation->set_rules('cat_name', 'Category Name', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            $data['title']      = 'Edit Category';
            $data['breadcrumb'] = 'Edit Category';
            $data['layout']     = 'product/edit_category.php';
            $data['data']       = $this->db_model->select_multi('id, cat_name, parent_cat, description', 'product_categories', array('id' => $this->uri->segment(3)));
            $this->db->select('id, cat_name');
            $data['parents'] = $this->db->get('product_categories')->result_array();
            $this->load->view('admin/index', $data);
        } else {
            $this->db->where('id', $this->input->post('id'));
            $data = array(
                'cat_name'    => $this->input->post('cat_name'),
                'parent_cat'  => $this->input->post('parent_cat'),
                'description' => $this->input->post('description'),
            );
            $this->db->update('product_categories', $data);
            $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Category Updated Successfully.</div>');
            redirect('admin/manage_cat');
        }

    }
   
 
   
    public function expense()
    {
        $config['base_url']   = site_url('admin/expense');
        $config['per_page']   = 50;
        $config['total_rows'] = $this->db_model->count_all('admin_expense');
        $page                 = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->pagination->initialize($config);

        $this->db->order_by('id', 'DESC');
        $this->db->limit($config['per_page'], $page);

        $data['expense']    = $this->db->get('admin_expense')->result();
        $data['title']      = 'Manage Expenses';
        $data['breadcrumb'] = 'Manage Expenses';
        $data['layout']     = 'misc/expenses.php';
        $this->load->view('admin/index', $data);
    }

    public function expense_remove($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('admin_expense');
        $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Expense Entry Deleted Successfully.</div>');
        redirect('admin/expense');
    }

    public function format_remove($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('invoice_format');
        $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Format Deleted Successfully.</div>');
        redirect('admin/format_manage');
    }

    public function fbank_remove($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('bank');
        $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Bank Deleted Successfully.</div>');
        redirect('admin/bank');
    }

    public function customer_remove($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('customers');
        $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Customer Deleted Successfully.</div>');
        redirect('admin/customer');
    }
    
    public function deposit_history()
    {
        $data['title']  = 'Deposit Request List';
        $data['layout'] = 'support/deposit_history.php';
        $this->load->view('admin/base', $data);
    }
    
    public function column_remove($id)
    {
        $this->load->dbforge();
        $columnName = $this->db_model->select('name', 'invoice_columns', array('id' => $id));
        $this->load->database();
        if ($this->db->table_exists('invoice')) {
            if ($this->db->field_exists($columnName, 'invoice')) {
                $this->dbforge->drop_column('invoice', $columnName);
                $this->db->where('id', $id);
                $this->db->delete('invoice_columns');
                $this->session->set_flashdata('common_flash', '<div class="alert alert-warning">Column deleted successfully.</div>');
                redirect('admin/add_col');
            } 
            else {
                $this->session->set_flashdata('common_flash', '<div class="alert alert-danger">The specified column does not exist in the table.</div>');
                redirect('admin/add_col');
            }
        }
        else {
            $this->session->set_flashdata('common_flash', '<div class="alert alert-danger">Something went wrong. The table does not exist.</div>');
            redirect('admin/add_col');
        }
    }
     
}


