<?php

defined('BASEPATH') OR exit('No direct script access allowed');
include(APPPATH.'libraries/razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
class Cart extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if ($this->login->check_member() == FALSE) {
            redirect(site_url('site/login'));
        }
        $this->load->library('pagination');
        $this->load->library('cart');
    }

    public function new_purchase() 
    {
        // Fetch Category
        $this->db->select('id,cat_name,description');
        $data['categories'] = $this->db->get('product_categories')->result();

        // Fetch selling products
        $this->db->select('*')->where('status', 'Selling')->limit(10);
        $data['product_top'] = $this->db->get('product')->result();

        // Recent product 
        $this->db->select('*')->limit(8);
        $this->db->order_by('created_date');
        $recent_products = $this->db->get('product')->result();

        $data['recent_products'] = $recent_products;
       
        $data['title']       = 'Buy Product Online ';
        $data['layout']      = 'shop/buy.php';
        $this->load->view('member/index', $data);
    }

    public function show_products() 
    {
        // Fetch Category
        $this->db->select('id,cat_name,description');
        $data['categories'] = $this->db->get('product_categories')->result();

       // Fetch selling products
        $this->db->select('*');
        if($this->uri->segment(3)!= 0){
              $this->db->where(array( 'status'   => 'Selling','category' => $this->uri->segment(3),));
        }else{
              $this->db->where(array('status'   => 'Selling',));
        }
        $data['product_top'] = $this->db->get('product')->result();

        // Recent product 
        $this->db->select('*')->limit(8);
        $this->db->order_by('created_date');
        $recent_products = $this->db->get('product')->result();
        $data['recent_products'] = $recent_products;


        $data['title']   = 'Select a Product Below: ';
        $data['layout']  = 'shop/buy.php'; 
        $this->load->view('member/index', $data);
    }
 
    public function view_product($id) 
    { 
        
        $product_data = $this->db_model->select_multi('*', 'product', array('id' => $id));
        
        $this->db->select('*');
        $this->db->like('prod_name', '%');
        $related_products = $this->db->get('product')->result();

        // Recent product 
        $this->db->select('*')->limit(8);
        $this->db->order_by('created_date');
        $recent_products = $this->db->get('product')->result();
        $data['recent_products'] = $recent_products;
        
        $data['title']      = 'Product Detail';
        $data['breadcrumb'] = 'Manage Products';
        $data['layout']     = 'shop/view_product.php';
        $data['prod_data']       = $product_data;
        $data['related_products'] = $related_products;
        $this->load->view('member/index', $data);
    }

    public function shop_list(){

        $this->db->select('*');
        $shop_list = $this->db->get('franchisee')->result();
      
        $data['title']      = 'Shop List';
        $data['breadcrumb'] = 'Shop List';

        $data['layout']     = 'shop/shop_list.php';
        $data['shop_list'] = $shop_list;
        $this->load->view('member/index', $data);
    }

    public function search() 
    { 
        $skeyword = $this->input->post('search');
        // Fetch Category
        $this->db->select('id,cat_name,description');
        $data['categories'] = $this->db->get('product_categories')->result();

        // Fetch selling products
         $this->db->select('*');
         $this->db->like('prod_name', $skeyword);
        $data['product_top'] = $this->db->get('product')->result();

        // Recent product 
        $this->db->select('*')->limit(8);
        $this->db->order_by('created_date');
        $recent_products = $this->db->get('product')->result();

        $this->db->select('*');
        $this->db->like('prod_name', $skeyword);
        $related_products = $this->db->get('product')->result();
        
        $data['title']      = 'Search Result';
        $data['breadcrumb'] = 'Search Result';
        $data['layout']     = 'shop/buy.php';
        $data['recent_products']       = $recent_products;
        $data['related_products'] = $related_products;
        
        $this->load->view('member/index', $data);
    }


    public function buy_2($product_id)
    {
       
        $product_data = $this->db_model->select_multi('prod_name, prod_price, qty,image,prod_desc,gst,dealer_price', 'product', array('id' => $product_id));

        if ($product_data->qty == 0) {
            $this->session->set_flashdata('common_flash', '<div class="alert alert-danger">Stock has less qty.</div>');
            redirect('cart/new_purchase');
        }
        $maxid = 0;
        $row = $this->db->query('SELECT MAX(orderid) AS `maxid` FROM `product_sale`')->row();
        if ($row) {
            $maxid = $row->maxid; 
            $o_id = $maxid + 1 ;
        }

        $discount = $product_data->prod_price - $product_data->dealer_price;
        $datas                          = array(
            'id'    => $product_id,
            'qty'   => 1,
            'prod_price'=> $product_data->prod_price,
            'dealer_price' =>$product_data->dealer_price,
            'gst'   => $product_data->gst,
            'gst_amt' =>$product_data->dealer_price*($product_data->gst/100),
            'price' => $product_data->dealer_price + $product_data->dealer_price*($product_data->gst/100),
            'product_cost' => $product_data->dealer_price + ($product_data->dealer_price*($product_data->gst/100)),
            'discount' => 0,
            'name'  => $product_data->prod_name,
            'prod_desc'  => $product_data->prod_desc,
            'image' => $product_data->image,
            'o_id' => $o_id,
            );

        
        $this->cart->product_name_rules = '[:print:]';
        $this->cart->insert($datas);
        $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Product Added to Cart. Want to purchase more ?.</div>');
        redirect('cart/pre_checkout');
    }



     public function apply_coupon(){

        // $ccode = $this->input->post('ccode');
        // $coupdata = $this->db_model->select_multi('*', 'coupon', array('coupon' => $ccode,'userid'=>$this->session->user_id));

        //         $datas = array(
        //             'discount'   => '5',
        //         );
        //         $this->cart->product_name_rules = '[:print:]';
        //     $this->cart->insert($datas);
        
        
        // $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Cart Updated.</div>');
        // redirect('cart/pre_checkout');

     }

     public function update()
    {
        $i = 0;
        foreach ($this->cart->contents() as $item) {
            $qty1 = count($this->input->post('qty'));
            for ($i = 0; $i < $qty1; $i++) {
                $data = array(
                    'rowid' => $_POST['rowid'][$i],
                    'qty'   => $_POST['qty'][$i],
                );

                $this->cart->update($data);
            }

        }


        $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Cart Updated.</div>');
        redirect('cart/pre_checkout');

    }


    public function pre_checkout()
    {   
        $total_amt = $this->amount_inword(round($this->cart->total()));
        $data['total'] = $total_amt;
        $data['title']  = 'Checkout';
        $data['layout'] = 'shop/pre_checkout.php';
        $this->load->view('member/index', $data);
    }

    function amount_inword(float $number)
    {
        $decimal = round($number - ($no = floor($number)), 2) * 100;
        $hundred = null;
        $digits_length = strlen($no);
        $i = 0;
        $str = array();
        $words = array(0 => '', 1 => 'one', 2 => 'two',
            3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
            7 => 'seven', 8 => 'eight', 9 => 'nine',
            10 => 'ten', 11 => 'eleven', 12 => 'twelve',
            13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
            16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
            19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
            40 => 'forty', 50 => 'fifty', 60 => 'sixty',
            70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
            $digits = array('', 'hundred','thousand','lakh', 'crore');
            while( $i < $digits_length ) {
                $divider = ($i == 2) ? 10 : 100;
                $number = floor($no % $divider);
                $no = floor($no / $divider);
                $i += $divider == 10 ? 1 : 2;
                if ($number) {
                    $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                    $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                    $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
                } else $str[] = null;
            }
            $Rupees = implode('', array_reverse($str));
            $paise = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
        return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
    }


    public function pg_status_message(){
        $this->session->set_flashdata('common_flash', '<div class="alert alert-danger">Faild to add money or payment gateway error!</div>');
        redirect(site_url('cart/pre_checkout'));

    }
    
    
    public function walletPaymentProcess($o_id) {
		$get_balance = $this->db_model->select('balance', 'wallet', array('userid' => $this->session->user_id));
        $userinfo    = $this->db_model->select_multi('name,phone,username', 'member', array('id' => $this->session->user_id));
        $coupon      = $this->input->post('coupon');
        if($coupon != ''){
            $coupon_data = $this->db_model->select_multi('*', 'coupon', array('id' => $coupon));
            if($get_balance >= $this->cart->total()-$coupon_data->coupon_amt){   
                $data = array(
                   'status' => 'Used',                   
                );
                $this->db->where('id', $coupon);
                $this->db->update('coupon', $data);
                $w_transData = array(
                    'userid'     => $this->session->user_id,
                    'type'       => 'Coupon Discount',
                    'amount'     => $coupon_data->coupon_amt,
                    'ref_id'     => $o_id,
                );                       
                $this->db->insert('wallet_transaction', $w_transData);
                $cart_total  = $this->cart->total() - $coupon_data->coupon_amt;
            }
            else{
                $add_money = $this->cart->total() - $get_balance - $coupon_data->coupon_amt; 
                $this->session->set_flashdata('common_flash', '<div class="alert alert-danger">Your Wallet donot have suficient fund to complete this purchase. Wallet need to have atleast: ' . config_item('currency') . $add_money . '<a href="../gateway/registration_form"> Add Money</a></div>');
                $this->session->set_userdata('_order_id_', $o_id);
                $this->session->set_userdata('_user_name_', $userinfo->name);
                $this->session->set_userdata('_phone_', $userinfo->phone);
                $this->session->set_userdata('_price_', $add_money);
                redirect(site_url('cart/pre_checkout')); 
            }
        }
        else{
            $cart_total = $this->cart->total();
        }
        
        if ($get_balance < $cart_total){
            $add_money = $cart_total - $get_balance; 
            $this->session->set_flashdata('common_flash', '<div class="alert alert-danger">Your Wallet donot have suficient fund to complete this purchase. Wallet need to have atleast: ' . config_item('currency') . $add_money . '<a href="../gateway/registration_form"> Add Money</a></div>');
            $this->session->set_userdata('_order_id_', $o_id);
            $this->session->set_userdata('_user_name_', $userinfo->name);
            $this->session->set_userdata('_phone_', $userinfo->phone);
            $this->session->set_userdata('_price_', $add_money);
            redirect(site_url('cart/pre_checkout'));
        }
        else{
                $this->session->set_userdata('_order_id_', $o_id);
                $data = array(
                    'balance' => ($get_balance - $cart_total),                   
                );
                $this->db->where('userid', $this->session->user_id);
                $this->db->update('wallet', $data);
                
                if ($cart = $this->cart->contents())
                 {
                    foreach ($cart as $item):
                      $ad_cost = $this->db_model->select('purchase_price', 'product', array('id' => $item['id']));
                      $array = array(
                            'product_id'       => $item['id'],
                            'userid'           => $this->session->user_id,
                            'qty'              => $item['qty'],
                            'cost'             => $item['price'] * $item['qty'],
                            'date'             => date('Y-m-d'),
                            'gst'              => $item['dealer_price'] * $item['qty'] * $item['gst'] / 100,
                            'orderid'          => $o_id,
                            'purchase_cost'    => $o_id,

                        );
                        $this->db->insert('product_sale', $array);

                        $w_transData = array(
                            'userid'     => $this->session->user_id,
                            'type'       =>'Debit',
                            'amount'     => $item['price'] * $item['qty'],
                            'ref_id'     => $o_id,
                        );                       
                        $this->db->insert('wallet_transaction', $w_transData);

                        $data = array(
                            'product_id' => $item['id'],
                            'order_id' => $o_id,
                            'cost'     => $item['price'] * $item['qty'],
                        );
                        $this->db->insert('product_item_sale', $data);
                        
                    endforeach;
                } 
                
                $top_upp = $this->db_model->select('topup', 'member', array('id' => $this->session->user_id));
                if($top_upp > 0){
                    $get_balance2 = $this->db_model->select('balance', 'wallet', array('userid' => $this->session->user_id));
                    $percent = 20;
                    $value = $cart_total;
                    $discount = ($percent/100) * $value;
                    
                    $coppon = array(
                        'userid'         => $this->session->user_id,
                        'coupon_amt'     => $discount,
                        'status'         => 'Un-Used',
                    );                       
                    $this->db->insert('coupon', $coppon);
                    
                    // $data = array(
                    //      'balance' => $get_balance2 + $discount,                   
                    // );
                    // $this->db->where('userid', $this->session->user_id);
                    // $this->db->update('wallet', $data);
                }
                
            $this->session->unset_userdata('_user_id_');
            $this->session->set_flashdata('common_flash', '<div class="alert alert-success">Thank you for Purchasing with us</div>');
            redirect('cart/checkout_complete');
        }
       
	}

     public function razorpayPaymentProcess($o_id,$postData) {
		   
		$this->load->library('razorpay');
		$userinfo = $this->db_model->select_multi('name,phone,username,email', 'member', array('id' => $this->session->user_id));
		$ubank=$this->db_model->select_multi('btc_address', 'member_profile', array('userid' => $e->userid)); $ubank=$this->db_model->select_multi('*', 'member_profile', array('userid' => $e->userid));
       
		$orderData = array();
		$orderData['receipt'] = $o_id;
		$orderData['amount'] = isset($postData['amount'])?$postData['amount']:0;
		$orderData['prefill_name'] = isset($userinfo->name)?$userinfo->name:'';
		$orderData['prefill_email'] = isset($userinfo->email)?$userinfo->email:'';
		$orderData['prefill_contact'] = isset($userinfo->phone)?$userinfo->phone:'';
		$orderData['notes_address'] = isset($ubank->btc_address)?$ubank->btc_address:'';
		 
		$this->session->set_userdata('_user_name_', $userinfo->name);
		$this->session->set_userdata('_phone_', $userinfo->phone);
		$this->session->set_userdata('_price_', $postData['amount']);
		$data['payment_method'] = 'razorpay';
		$data['payment_sataus'] = 'failed';
		$data['orderid'] = $o_id;
        $saleIds = $this->paymentAndSales($data);
		$orderData['shopping_order_id'] = implode(",",$saleIds);

		$this->razorpay->processPayment($orderData);
	 }	 

    function checkout($o_id)
    {

		$paymentmethod = $this->input->post('paymentmethod');
		
		if (empty($paymentmethod) || empty($o_id) ) {
			$this->session->set_flashdata('common_flash', '<div class="alert alert-success">The payment method / Order # was missing</div>');
			redirect('cart/pre_checkout');
		}
		
		if($paymentmethod =='wallet' ){
			$this->walletPaymentProcess($o_id);
		}	
		else if($paymentmethod =='razorpay') {
			$this->razorpayPaymentProcess($o_id,$this->input->post());
		}
		else{
			redirect('cart/pre_checkout');
		}	
		
        
    }
	
	public function razorpayverify()
    {
		//$keyId = 'rzp_test_eop7PF7LKTnUyZ';
		//$keySecret = 'rcud74C7SaKDk1SrnFbQxR6P';
		$this->config->load('pg');
		//echo config_item('RAZOR_KEY_ID');exit;
		$keyId = config_item('RAZOR_KEY_ID');
        $keySecret = config_item('RAZOR_KEY_SECRET'); //RAZOR_KEY_SECRET;
		$success = true;

		$error = "Payment Failed";
		/*echo "<pre>";
		print_r($_POST);
		exit;*/

		if (empty($_POST['razorpay_payment_id']) === false)
		{
			$api = new Api($keyId, $keySecret);
            
			try
			{
				// Please note that the razorpay order ID must
				// come from a trusted source (session here, but
				// could be database or something else)
				$attributes = array(
					'razorpay_order_id' => $_SESSION['razorpay_order_id'],
					'razorpay_payment_id' => $_POST['razorpay_payment_id'],
					'razorpay_signature' => $_POST['razorpay_signature']
				);

				$api->utility->verifyPaymentSignature($attributes);
			}

            
			catch(SignatureVerificationError $e)
			{
				$success = false;
				$error = 'Razorpay Error : ' . $e->getMessage();
			}
		}

		if ($success === true)
		{
			$html = "<p>Your payment was successful</p>
				 <p>Payment ID: {$_POST['razorpay_payment_id']}</p>";

			$data['razorpay_payment_id'] = $_POST['razorpay_payment_id'];
			$data['razorpay_order_id'] = $_POST['razorpay_order_id'];
			$data['sale_ids'] = $_POST['shopping_order_id'];
			$data['payment_sataus'] = 'success';
			$this->updatePaymentStatus($data);			  
			$this->session->set_flashdata('common_flash', '<div class="alert alert-success">Thank you for Purchasing with us'.$html.'</div>');
            
			redirect('cart/checkout_complete');	 
				 
		}
		else
		{
			$html = "<p>Your payment failed</p>
				 <p>{$error}</p>";
			$this->session->set_flashdata('common_flash', '<div class="alert alert-danger">'.$html.'</div>');
			redirect('cart/checkout_failed');	
		}

		//echo $html;
    }		
	
	public function updatePaymentStatus($data) {
		$sale_ids = isset($data['sale_ids'])?explode(',',$data['sale_ids']):'';
		$payment_sataus = isset($data['payment_sataus'])?$data['payment_sataus']:'';
		$razorpay_payment_id = isset($data['razorpay_payment_id'])?$data['razorpay_payment_id']:'';
		$razorpay_order_id = isset($data['razorpay_order_id'])?$data['razorpay_order_id']:'';
		$this->db->trans_start();

		foreach ($sale_ids as $saleId){
			//$query = $this->db->where('id', $saleId)->from('cron')->get();	
			//$this->db->set('last_run_at', 'now()', false)->where('id', $row->id)->update('cron');
			$this->db->where('id', $saleId);
			$this->db->update('product_sale', array('payment_sataus' => $payment_sataus,'razorpay_payment_id' => $razorpay_payment_id,'razorpay_order_id'=>$razorpay_order_id ));
	    }		
        $this->db->trans_complete();
		
		return $this->db->trans_status();
		
		
	}
	
	public function paymentAndSales($data) {
		
		 if ($cart = $this->cart->contents())
         {
            $saleIds = array();
            foreach ($cart as $item):
              $array = array(
                    'product_id' => $item['id'],
                    'userid'     => $this->session->user_id,
                    'qty'        => $item['qty'],
                    'cost'       => $item['price'] * $item['qty'],
                    'date'       => date('Y-m-d'),
                    'orderid'    => $data['orderid'],
					'payment_method' =>$data['payment_method'],
					'payment_sataus' =>$data['payment_sataus']

                );
              
                $this->db->insert('product_sale', $array);
                $saleIds[] = $this->db->insert_id();
				 
            endforeach;

        }
        $this->session->unset_userdata('_user_id_');
        return $saleIds;        

       

	}
	
	public function checkout_failed()
    {
        $data['title']  = 'Payment Failed';
        $data['layout'] = 'shop/checkout_failed.php';
        $this->load->view('member/index', $data);
    }
    
    public function checkout_complete()
    {


        $this->db->select('*'); 
        $this->db->group_by('product_sale.orderid');
         $this->db->where('product_sale.orderid', $this->session->_order_id_);
        $this->db->from('product_sale');
        $this->db->join('member', 'product_sale.userid = member.id');
        $data['invoice_data'] = $this->db->get()->result_array();

        $data['title']  = 'Invoice';
        $data['layout'] = 'shop/checkout_complete.php';
        $this->load->view('member/index', $data);
    }

     public function my_customers()
    {
        $this->db->select('*');
        $this->db->select_sum('cost');
        $this->db->where('member.sponsor',$this->session->user_id);
        $this->db->group_by('orderid');
        $this->db->from('product_sale');
        $this->db->join('member', 'product_sale.userid = member.id');

        $data['purchase_data'] = $this->db->get()->result_array();

        $data['title']  = 'My Customers';
        $data['layout'] = 'shop/my_customers.php';
        $this->load->view('member/index', $data);

    }


    public function old_purchase()
    {
        $config['base_url']   = site_url('cart/old_purchase');
        $config['per_page']   = 50;
        $config['total_rows'] = $this->db_model->count_all('product_sale', array('userid' => $this->session->user_id));
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->pagination->initialize($config);

        $this->db->select('*')->from('product_sale')
                 ->where('userid', $this->session->user_id)->limit($config['per_page'], $page);

        $data['data']   = $this->db->get()->result();


        $this->db->select('*'); 
        $this->db->select_sum('cost');
        $this->db->group_by('orderid');
        $this->db->where('member.id', $this->session->user_id);
        $this->db->from('member');
        $this->db->join('product_sale', 'product_sale.userid = member.id');
       
        $data['purchase_data'] = $this->db->get()->result_array();
        $data['title']  = 'My Old Purchases';
        $data['layout'] = 'shop/my_purchases.php';
        $this->load->view('member/index', $data);

    }
}
