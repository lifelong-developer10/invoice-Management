
<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
    <?php echo form_open('accounting/store_invoice2') ?>
                <div class="row p-4">
                    <div class="form-group col-sm-12">
                        <label>Invoice Name *</label>
                        <input required type="text" name="invoice_name" class="form-control" value="<?php echo $result->invoice_name ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Invoice Date *</label>
                        <input type="text"  value="<?php echo date('Y-m-d') ?>" value="<?php echo $result->date ?>" name="invoice_date" class="form-control datepicker">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Company Name *</label>
                        <input  type="text" name="company_name" class="form-control" value="<?php echo $result->company_name ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Company Address *</label>
                        <input  type="text" name="bill_add" class="form-control" value="<?php echo $result->company_address ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Vat No *</label>
                        <input  type="text" name="vat_no" class="form-control" value="<?php echo $result->vat_no ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Contact No *</label>
                        <input  type="number" name="phone" class="form-control" value="<?php echo $result->contact_no ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Email Id *</label>
                        <input  type="email" name="email" class="form-control" value="<?php echo $result->email ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Total Amount *</label>
                        <input  type="number" class="form-control" name="total_amt" value="<?php echo $result->total_amt ?>">
                        <input  type="hidden" class="form-control" name="id" value="<?php echo $result->id ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Paid Amount *</label>
                        <input  type="number" class="form-control" name="paid_amt" value="<?php echo $result->paid_amt ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Currency *</label><br>
                        <select required name="currency" class="form-control">
                            <option value="" selected disabled>Select Currency</option>
                            <?php
                                if($result->currency == "$"){
                                    $msgg = 'Dollar';
                                }
                                else{
                                    $msgg = 'INR';
                                }
                            ?>
                            <option value="<?php echo $result->currency ?>" selected><?php echo $msgg ?></option>
                            <option value="₹">INR</option>
                            <option value="$">DOLLAR</option>
                        </select>
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Bank Details *</label><br>
                        <select required name="bank" class="form-control">
                            <option value="" selected disabled>Select Your Bank</option>
                            <option value="<?php echo $result->bank ?>" selected><?php echo $this->db_model->select('name', 'bank', array('id' => $result->bank));   ?></option>
                            <?php
                                $query = $this->db->get('bank')->result();
                                foreach ($query as $row) {
                            ?>
                                <option value="<?php echo $row->id ?>"><?php echo $row->name ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <!--<div class="row p-4">-->
                <?php
                    // $query        = $this->db->where('id', $result->formatid)->get('invoice_format')->result();
                    // $columns      = $query[0]->labels;
                    // $columns2     = $query[0]->columns;
                    // $columnNames  = explode(',', $columns);
                    // $columnNames2 = explode(',', $columns2);
                    // foreach (array_combine($columnNames, $columnNames2) as $columnName => $columnName2) {
                ?>
                <!--<div class="col-sm-4">-->
                <!--    <label><?php echo $columnName ?> *</label>-->
                <!--    <textarea required  class="form-control" name=""><?php echo $result->$columnName2 ?></textarea>-->
                <!--</div>-->
                <?php 
                    // } 
                ?>
                <!--</div>-->
                <div class="">
                    <button type="submit" class="btn btn-primary mx-4 mb-4">Update</button>
               </div>







