<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
<?php
    $format_cols = $this->db_model->select_multi('columns', 'invoice_format', array('id' => $result->formatid));
    var_dump($format_cols);
// $format_id = $result->formatid;

// // Define an array of column names you want to retrieve
// $columnsToRetrieve = array('column1', 'column2', 'columnA', 'columnB');

// // Initialize the select string with the dynamic columns
// $selectString = '';
// foreach ($columnsToRetrieve as $column) {
//     $selectString .= $column . ', ';
// }

// // Remove the trailing comma and space
// $selectString = rtrim($selectString, ', ');

// // Construct the query
// $this->db->select($selectString);
// $this->db->from('invoice_format');
// $this->db->join('other_table', 'invoice_format.id = other_table.formatid', 'inner');
// $this->db->where('invoice_format.id', $format_id);

// $query = $this->db->get();

// if ($query->num_rows() > 0) {
//     foreach ($query->result() as $row) {
//         foreach ($columnsToRetrieve as $column) {
//             $columnValue = $row->$column;
//             // Access the dynamic column values as needed
//             echo "$column: $columnValue, ";
//         }
//         echo "\n";
//     }
// }

?>







