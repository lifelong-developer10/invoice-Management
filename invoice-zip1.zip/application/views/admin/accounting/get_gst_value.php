<?php
// Assuming you're using mysqli to interact with your database
$servername = "localhost"; // Your MySQL server address
$username = "root"; // Your MySQL username
$password = " "; // Your MySQL password
$database = "invoice1"; // Your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



if (isset($_POST['business_type_id'])) {
    $businessTypeId = $_POST['business_type_id'];

    // Query to fetch GST value based on business type ID
    $query = $pdo->prepare("SELECT market_gst FROM gst_type WHERE id = ?");
    $query->execute([$businessTypeId]);
    $result = $query->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        echo $result['market_gst'];
    } else {
        echo '0'; 
    }
}
?>


?>
