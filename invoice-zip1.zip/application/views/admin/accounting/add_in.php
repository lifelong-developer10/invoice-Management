<?php
    $format_id = $this->uri->segment(3);
?>
<!-- Bootstrap CSS -->

<!-- Bootstrap JavaScript (make sure it's included after jQuery) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-..."></script>

<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
<?php
 if($format_id == NULL){
?>
<div class="row p-4">
    <div class="form-group col-12">
        <label>Select Format *</label>
        <select name="invoice_name" id="invoice_name" class="form-control" required>
            <option value="">Select an option</option>
            <?php
                $query = $this->db->get('invoice_format')->result();
                foreach ($query as $row) {
            ?>
                <option value="<?php echo $row->id ?>"><?php echo $row->name ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="form-group col-12">
        <label>Select Customer *</label>
        <select name="customer_name" id="customer_name" class="form-control">
            <option value="">Select an Customer</option>
            <?php
                $query = $this->db->get('customers')->result();
                foreach ($query as $row) {
            ?>
                <option value="<?php echo $row->id ?>"><?php echo $row->name ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="form-group col-12">
    <label>Select Invoice Category *</label>
    <select name="business_type" id="business_type" class="form-control">
        <option value="">Select a business type</option>
        <?php
            $business_types = $this->db->get('gst_type')->result();
            foreach ($business_types as $type) {
                echo '<option value="' . $type->id . '" data-gst="' . $type->market_gst . '">' . $type->business_type . '</option>';
            }
        ?>
    </select>
</div>
<div class="form-group col-12">
    <a href="#" id="get_format_btn" class="btn btn-xs btn-success">Get Format</a>
</div>
<input type="hidden" id="gst-hidden" name="gst">


<!-- Display area for the message -->
<div id="message"></div>

<script>
    document.getElementById("get_format_btn").addEventListener("click", function() {
        var selectedOption = document.getElementById("invoice_name").value;
        var selectedCustomer = document.getElementById("customer_name").value;
        var selectedBusinessType = document.getElementById("business_type").value;
        var gstValue = document.getElementById("business_type").options[document.getElementById("business_type").selectedIndex].getAttribute("data-gst");

        if (selectedOption !== "" && selectedCustomer !== "" && selectedBusinessType !== "") {
            // Append the fetched GST value to the URL
            var url = "<?php echo site_url('accounting/add_in/') ?>" + selectedOption + "/" + selectedCustomer + "/" + selectedBusinessType + "/" + gstValue;
            window.location.href = url; // Redirect to the specified URL
        } else {
            // Show a message indicating that all options need to be selected
            showMessage("Please select all options. GST value: " + gstValue);
        }
    });

   
    function showMessage(message) {
        var messageDiv = document.getElementById("message");
        messageDiv.textContent = message;
    }
</script>





<?php }else{ ?>
    <?php echo form_open('accounting/store_invoice') ?>

<?php
    $customer_id = $this->uri->segment(4);
    $cdata       = $this->db_model->select_multi('*', 'customers', array('id' => $customer_id));
?>


                <div class="row p-4">
                    <div class="form-group col-sm-12">
                        <label>Invoice Name *</label>
                        <input required type="text" name="invoice_name" class="form-control">
                        <input  type="hidden" name="format_id" value="<?php echo  $format_id ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Invoice Date *</label>
                        <input type="text"  value="<?php echo date('Y-m-d') ?>" name="invoice_date" class="form-control datepicker" required>
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Company Name *</label>
                        <input  type="text" name="company_name" class="form-control" value="<?php echo  $cdata->cname ?>">
                    </div>
                <div class="form-group col-12">
    <label>GST Rate (%) *</label>
    <input required type="text" class="form-control" name="gst_display" id="gst-display">
</div>
          <div class="form-group col-sm-6">
                        <label>Company Address *</label>
                        <input  type="text" name="bill_add" class="form-control" value="<?php echo  $cdata->address ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Vat No *</label>
                        <input  type="text" name="vat_no" class="form-control" value="<?php echo  $cdata->vat ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Contact No *</label>
                        <input  type="text" name="phone" class="form-control" value="<?php echo  $cdata->phone ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Email Id *</label>
                        <input  type="email" name="email" class="form-control" value="<?php echo  $cdata->email ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Total Amount *</label>
                        <input  type="number" class="form-control" name="total_amt" value="0" required>
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Paid Amount *</label>
                        <input  type="number" class="form-control" name="paid_amt" required>
                    </div>
                    <div class="form-group col-sm-6">
                        <label>Currency *</label><br>
                        <select required name="currency" class="form-control">
                            <option value="" selected disabled>Select Currency</option>
                            <option value="₹">INR</option>
                            <option value="$">DOLLAR</option>
                        </select>
                    </div>
                    
                    <div class="form-group col-sm-6">
                        <label>Bank Details *</label><br>
                        <select required name="bank" class="form-control">
                            <option value="" selected disabled>Select Your Bank</option>
                            <?php
                                $query = $this->db->get('bank')->result();
                                foreach ($query as $row) {
                            ?>
                                <option value="<?php echo $row->id ?>"><?php echo $row->name ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <input type="hidden" id="dup" value="1">
                <div class="row p-4">
                <input type="hidden" id="totalSumInput" name="total_sum" value="">

                <div id="message"></div>


    <?php
    $query = $this->db->where('id', $format_id)->get('invoice_format')->result();
    $columns = $query[0]->labels;
    $columns2 = $query[0]->columns;
    $columnNames = explode(',', $columns);
    $columnNames2 = explode(',', $columns2);
    foreach (array_combine($columnNames, $columnNames2) as $columnName => $columnName2) {
        ?>
        
    <?php } ?>
</div>
<div id="res"></div>
<div class="p-4"><a href="javascript:;" onclick="add_item()" class="btn btn-xs btn-success" id="addBtn">Add Item +</a></div>
<button type="submit" class="btn btn-primary mx-4 mb-4">Create &rarr;</button>

</div>
<?php } ?>
<?php echo form_close() ?>
</div>
</div>
<!-- Include jQuery library -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    // Get the current URL
var currentUrl = window.location.href;

// Split the URL by '/'
var urlParts = currentUrl.split('/');

// Get the last part of the URL, which should be the GST value
var gstValue = urlParts[urlParts.length - 1];

// Now you have the GST value, you can use it as needed
console.log("GST Value:", gstValue);

var gstInput = document.getElementById("gst-display");

// Set the value of the GST input field
gstInput.value = gstValue;
    </script>

<?php
// Get the GST value from the URL
$gstValue = $_GET['gst'];

// Save the GST value to the database
$data = array(
   'gst' => $gstValue,
   // Add other form field values here
);
$this->db->insert('invoice', $data);
 ?>


<!-- Your JavaScript code -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    $(document).ready(function () {
        // Initialize total calculation on page load
        calculateTotal();

        $('#addBtn').on('click', function () {
            add_item();
        });

        $('#res').on('click', '.remove-item', function () {
            $(this).closest('.row.p-4').remove();
            calculateTotal(); // Recalculate total after removing an item
        });

        $('#res').on('input', '.generated-input.gst, .generated-input.subtotal', function () {
            calculateItemTotal($(this).closest('.row.p-4'));
        });
$(document).ready(function () {
    var currentUrl = window.location.href;

    // Split the URL by '/'
    var urlParts = currentUrl.split('/');

    // Get the last part of the URL, which should be the GST value
    var fetchedGST = urlParts[urlParts.length - 1];

    $('#res').on('blur', '.generated-input.gst', function () {
                var inputValue = $(this).val().trim();
                // Ensure the input is a number and is not empty
                if (inputValue !== '' && !isNaN(inputValue)) {
                    // Check if the entered GST value matches the fetched GST value
                    if (inputValue !== fetchedGST) {
                        // GST value does not match, show an alert
                        alert('The entered GST value does not match the market GST value. Please enter the correct GST RATE%.');
                        // Reset the value of the GST field
                        $(this).val('');
                    }
                } else {
                    // Invalid input, reset the value of the GST field
                    alert('Please enter a valid GST value.');
                    $(this).val('');
                }
                calculateItemTotal($(this).closest('.row.p-4'));
            });
});

        //  function add_item() {
        //   var rand = parseInt($('#dup').val()) + 1;
        //   $('#dup').val(rand);
        //   var data = '<div class="row p-4" id="' + rand + '">\n';

        //    <?php foreach (array_combine($columnNames, $columnNames2) as $columnName => $columnName2) { ?>
        //         data += '    <div class="col-sm-4">\n' +
        //              '        <label><?php echo $columnName ?> *</label>\n' +
        //            '        <input required type="text" class="form-control generated-input <?php echo $columnName2 ?>" name="<?php echo $columnName2 ?>[]">\n' +
        //              '    </div>\n';
        //    <?php } ?>
        //     data += '    <div class="mt-3">&nbsp;&nbsp;&nbsp;<a href="javascript:;" class="btn btn-xs btn-danger remove-item">Remove</a></div>\n';
        //      data += '</div>';
        //     $('#res').append(data);
        //  }
     
        function add_item() {
    var rand = parseInt($('#dup').val()) + 1;
    $('#dup').val(rand);
    var data = '<div class="row p-4" id="' + rand + '">\n';

    <?php foreach (array_combine($columnNames, $columnNames2) as $columnName => $columnName2) { ?>
        data += '    <div class="col-sm-4">\n' +
             '        <label><?php echo $columnName ?> *</label>\n' +
           '        <input required type="text" class="form-control generated-input <?php echo $columnName2 ?>" name="<?php echo $columnName2 ?>[]" <?php if($columnName2 === 'gst') { echo 'value="' . $gstValue . '"'; } ?> >\n' +
             '    </div>\n';
    <?php } ?>
    data += '    <div class="mt-3">&nbsp;&nbsp;&nbsp;<a href="javascript:;" class="btn btn-xs btn-danger remove-item">Remove</a></div>\n';
    data += '</div>';
    $('#res').append(data);
}

    });
  

        function calculateTotal() {
            var totalSum = 0;

            $('.row.p-4').each(function () {
                var subtotal = parseFloat($(this).find('.generated-input.subtotal').val()) || 0;
                var gstPercentage = parseFloat($(this).find('.generated-input.gst').val()) || 0;

                var gstAmount = subtotal * (gstPercentage / 100);
                var total = subtotal + gstAmount;

                $(this).find('.generated-input.total').val(total.toFixed(2));
                totalSum += total;
            });

            $('input[name="total_amt"]').val(totalSum.toFixed(2));
        }

        function calculateItemTotal(item) {
            var subtotal = parseFloat(item.find('.generated-input.subtotal').val()) || 0;
            var gstPercentage = parseFloat(item.find('.generated-input.gst').val()) || 0;

            var gstAmount = subtotal * (gstPercentage / 100);
            var total = subtotal + gstAmount;

            item.find('.generated-input.total').val(total.toFixed(2));

            calculateTotal(); // Recalculate total for all items
        }
    ;
    
</script>
