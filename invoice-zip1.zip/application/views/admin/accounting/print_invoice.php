

<?php
   $format_id = $result->formatid;
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport"/>
    <meta name="author" content="Exolim"/>
    <meta name="robots" content="noindex, nofollow">
    <title>Management Dashboard | <?php echo config_item('company_name') ?></title>
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css"/>
    <style type="text/css">
        .border {
            border: 2px solid black;
        }
        b > p {
            font-size: 1em;
        }
        * {
            font-family: Calibri;
        }
        .t1 {
            width: 50%;
            padding: 2px;
        }
        #line_height {
            line-height: 1.2;
        }
        .logo-image {
            height: 100px;
            object-fit: contain;
        }
        .flex{
            display:flex;
        }
        .border_right,.border_bottom,.border_top{
            border-right:2px solid black;
        }
        .border_top{
            border-top:2px solid black;
        }
        .border_bottom,{
            border-bottom:2px solid black;
        }
        .flex-center {
    align-items: center;
}

.image-container {
    height: 100%;
}
.table2 {
  width: 100%;
  border-collapse: collapse;
  border-bottom:  2px solid black;
  border-left:  2px solid black;
  border-right:  2px solid black;
}
.wid{
    width: 100%; 
}
.table2 th,
.table2 td {
  border: 1px solid black;
  padding: 8px;
}

.table2 th {
  background-color: #f2f2f2;
  font-weight: bold;
}

.table2 th:first-child,
.table2 td:first-child {
  border-left: none;
}

.table2 th:last-child,
.table2 td:last-child {
  border-right: none;
}
  .invoice-wrapper {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-left:0.4em;
    padding-right:0.4em;
  }
    </style>
</head>
<body onload="print()">
<!-- <body> -->
<div class="container-fluid">
    <table class="border wid">
    <tr>
    <td colspan="2" class="flex flex-center">
        <div class="image-container">
            <img class="logo-image" src="<?php echo base_url('uploads/logo.png') ?>" alt="Company Logo">
        </div>
        <div>
            <h3 class="text-center text-info">SEASPEED MARINE SERVICES LLP.</h3>
            <b>
                <p>Registered with Seaman's Employment Office under Licence No. RPSL-MUM-162046 valid till 02/11/2025 Recruitment and Placement of Seafarers Rules 2016 & Regulation 1.4 of MLC 2006, as amended</p>
                <p>IN: AAR-8200</p>
            </b>
        </div>
    </td>
</tr>
    <tr class="border_top border_bottom">
        <td colspan="2">
<div class="invoice-wrapper">
  <p><b>INVOICE NO : <?php echo $this->db_model->select('invoice_name', 'invoice', array('id' => $id)); ?></b></p>
  
  <p style="margin-left: auto;"><b>DATE: 
    <?php
      $date = $this->db_model->select('date', 'invoice', array('id' => $id));
      $formattedDate = date_format(date_create($date), 'd-m-Y');
      echo $formattedDate;
    ?>
  </b></p>
</div>
        </td>
    </tr>
    <tr class="flex border_top">
        <td class="t_head2 t1 border_right">
            <p><b>TO,</b></p>
            <p>COMPANY NAME    : <?php echo $result->company_name ?></p>
            <p>COMPANY ADDRESS : <?php echo $result->company_address ?></p>
            <p>VAT NO          : <?php echo $result->vat_no ?></p>
            <p>CONTACT NO      : <?php echo $result->contact_no ?></p>
            <p>EMAIL ID        : <?php echo $result->email ?></p>
            <p>MARKET GST: <span id="market_gst"><?php echo htmlentities($result->gst); ?></span></p>



        </td>
        <td class="t_head2 t1">
            <p><b>FROM,</b></p>
            <div id="line_height">
                <p>SEASPEED MARINE SERVICES LLP.</p> 
                <p>GSTIN NO: 27AECFS8498E1ZI</p>
                <p>PAN NO: - AECFS8498E</p>
                <p>Office No A-601, Shelton Sapphire,</p>
                <p>Plot Number:18/19, Sector 15, Cbd ,</p>
                <p>Navi Mumbai – 400 614. Maharashtra, India.</p>
                <p>Contact NO: +91 9762345738 | Email: sachin@seaspeed.in</p>
            </div>
        </td>
    </tr>
    <tr class="border_top border_bottom">
        <td colspan="2">
            <p class="text-left px-2"><b>Kindly Arrange to Pay Following Amount Towards Services Rendered on Your Good Vessel as Mentioned Below:</b></p>
        </td>
    </tr>
 </table>
<table class="table2">
    <thead>
    <tr>
        <th>S NO</th>
        <?php
            $query = $this->db->where('id', $format_id)->get('invoice_format')->result();
            $columns = $query[0]->labels;
            $columnsArray = explode(',', $columns);
            $columnCount = count($columnsArray);
            $columns2 = $query[0]->columns;
            $columnNames = explode(',', $columns);
            $columnNames2 = explode(',', $columns2);


            foreach (array_combine($columnNames, $columnNames2) as $columnName => $columnName2) {
                echo '<th>'.$columnName.'</th>';
            }
        ?>
        </tr>
    </thead>
        <?php
            $invoiceData = $this->db->select(implode(',', $columnNames2))->from('invoice')->where('id', $id)->get()->result();
            
            $totalSum = 0; foreach ($invoiceData as $row) :
            $columns = (array) $row;
            $maxValues = 0;
            foreach ($columns as $key => $value) {
                $values = explode(', ', $value);
                $numValues = count($values);
                if ($numValues > $maxValues) {
                    $maxValues = $numValues;
                }
            }
            $numValues = $maxValues;
            $keys = array_keys($columns);
            $values = array_values($columns);
            $numKeys = count($keys);
            for ($i = 0; $i < $numValues; $i++) : 
        ?>
        <tr>
            <td><?php echo $i+1; ?></td>
            <?php for ($j = 0; $j < $numKeys; $j++) : ?>
            <td><?php $cellValues = explode(", ", $values[$j]);$cellValue = isset($cellValues[$i]) ? $cellValues[$i] : ''; echo $cellValue; ?></td>
            <?php
           
            
            
                if ($j === $numKeys - 1) {
                    $lastColumnValue = isset($cellValues[$i]) ? intval($cellValues[$i]) : 0;
                    
                }
            ?>
            <?php

$totalQuery = $this->db->select('total')->from('invoice')->where('id', $id)->get();
if ($totalQuery->num_rows() > 0) {
    $totalRow = $totalQuery->row();
    $totalSum = $totalRow->total;
} else {
   
    $totalSum = 0; 
}
?> 
<?php endfor; ?>
        </tr>
        <?php endfor; ?>
        <?php endforeach; ?>
    <tr>
        <?php
            $t = 0;
            while($t <= $columnCount-1){
                $t++;
                echo "<td style='border-left: none;border-right: none;'></td>";
            }
        ?>
        <td colspan="<?php echo $columnCount; ?>"><b>Total : <?php echo $this->db_model->select('currency', 'invoice', array('id' => $id)).' ' .$totalSum; ?></b></td>
    </tr>











    
    <tr>
        <td colspan="<?php echo $columnCount + 1 ?>" style="border: none;">
            <b>Amount In Words :-</b>
            <?php 
                if($this->db_model->select('currency', 'invoice', array('id' => $id)) == "₹"){
                    $resultword = amountToWords($totalSum);
                    $mss = " Rupees";
                }
                else{
                    $resultword = convertAmountToWords($totalSum);
                    $mss = " Dollar";
                }
            ?>
            <b style="float: right;">
                <?php echo '<span style="text-transform: uppercase;">' . $resultword . $mss . '</span>'; ?>
            </b>
        </td>
    </tr>

    <tr>
        <td style="border: none;" colspan="<?php echo $columnCount ?>">
            <p>Bank Details :-</p>
            <?php $id2 = $this->db_model->select('bank', 'invoice', array('id' => $id)) ?>
            <p>Account Holder : <?php echo $this->db_model->select('holder', 'bank', array('id' => $id2)) ?></p>
            <p>BANK NAME : <?php echo $this->db_model->select('name', 'bank', array('id' => $id2)) ?></p>
            <p>ACCOUNT NO: <?php echo $this->db_model->select('account', 'bank', array('id' => $id2)) ?></p>
            <p>BRANCH ACCOUNT : <?php echo $this->db_model->select('branch', 'bank', array('id' => $id2)) ?></p>
            <p>IFSC CODE : <?php echo $this->db_model->select('ifsc', 'bank', array('id' => $id2)) ?></p>
            <p>Swift Code : <?php echo $this->db_model->select('swift', 'bank', array('id' => $id2)) ?></p>
        </td>
        <td style="border: none;">
            <p >Receiver's Signature</p>
        </td>
    </tr>

</table>
</div>
</body>
<?php
function amountToWords($amount)
{
    $ones = array(
        0 => 'Zero',
        1 => 'One',
        2 => 'Two',
        3 => 'Three',
        4 => 'Four',
        5 => 'Five',
        6 => 'Six',
        7 => 'Seven',
        8 => 'Eight',
        9 => 'Nine',
        10 => 'Ten',
        11 => 'Eleven',
        12 => 'Twelve',
        13 => 'Thirteen',
        14 => 'Fourteen',
        15 => 'Fifteen',
        16 => 'Sixteen',
        17 => 'Seventeen',
        18 => 'Eighteen',
        19 => 'Nineteen'
    );

    $tens = array(
        2 => 'Twenty',
        3 => 'Thirty',
        4 => 'Forty',
        5 => 'Fifty',
        6 => 'Sixty',
        7 => 'Seventy',
        8 => 'Eighty',
        9 => 'Ninety'
    );

    // $amount = number_format($amount, 2, '.', '');

    // list($rupees, $paise) = explode('.', $amount);
    // Ensure that $amount is numeric before formatting
$amount = (float) $amount;

// Format the amount to two decimal places
$amount = number_format($amount, 2, '.', '');

// Split into rupees and paise
list($rupees, $paise) = explode('.', $amount);


    $rupees = (int)$rupees;

    $result = '';

    if ($rupees >= 10000000) {
        $result .= amountToWords(floor($rupees / 10000000)) . ' Crore ';
        $rupees %= 10000000;
    }

    if ($rupees >= 100000) {
        $result .= amountToWords(floor($rupees / 100000)) . ' Lakh ';
        $rupees %= 100000;
    }

    if ($rupees >= 1000) {
        $result .= amountToWords(floor($rupees / 1000)) . ' Thousand ';
        $rupees %= 1000;
    }

    if ($rupees >= 100) {
        $result .= amountToWords(floor($rupees / 100)) . ' Hundred ';
        $rupees %= 100;
    }

    if ($rupees > 0) {
        if ($rupees < 20) {
            $result .= $ones[$rupees];
        } else {
            $result .= $tens[floor($rupees / 10)];
            $rupees %= 10;
            if ($rupees > 0) {
                $result .= ' ' . $ones[$rupees];
            }
        }
    }
    
    if ($result == '') {
        $result = 'Zero';
    }

    
    // $result .= ' Rupees';
    if ($paise > 0) {
        if ($paise < 20) {
            $result .= ' Rupees and ' . $ones[$paise];
        } else {
            $result .= ' Rupees and ' . $tens[floor($paise / 10)];
            $paise %= 10;
            if ($paise > 0) {
                $result .= '-' . $ones[$paise];
            }
        }
        $result .= ' Paise';
    }

    return $result;
}
;
?>



<?php
function convertAmountToWords($amount) {
    $ones = array(
        0 => '',
        1 => 'one',
        2 => 'two',
        3 => 'three',
        4 => 'four',
        5 => 'five',
        6 => 'six',
        7 => 'seven',
        8 => 'eight',
        9 => 'nine',
        10 => 'ten',
        11 => 'eleven',
        12 => 'twelve',
        13 => 'thirteen',
        14 => 'fourteen',
        15 => 'fifteen',
        16 => 'sixteen',
        17 => 'seventeen',
        18 => 'eighteen',
        19 => 'nineteen'
    );

    $tens = array(
        0 => '',
        2 => 'twenty',
        3 => 'thirty',
        4 => 'forty',
        5 => 'fifty',
        6 => 'sixty',
        7 => 'seventy',
        8 => 'eighty',
        9 => 'ninety'
    );

    $amount = number_format($amount, 2, '.', '');
    $amount_parts = explode('.', $amount);
    $dollars = (int) $amount_parts[0];
    $cents = (int) $amount_parts[1];

    $words = '';

    if ($dollars > 0) {
        if ($dollars >= 1000000) {
            $millions = floor($dollars / 1000000);
            $words .= convertAmountToWords($millions) . ' million ';
            $dollars %= 1000000;
        }

        if ($dollars >= 1000) {
            $thousands = floor($dollars / 1000);
            $words .= convertAmountToWords($thousands) . ' thousand ';
            $dollars %= 1000;
        }

        if ($dollars >= 100) {
            $hundreds = floor($dollars / 100);
            $words .= convertAmountToWords($hundreds) . ' hundred ';
            $dollars %= 100;
        }

        if ($dollars > 0) {
            if ($dollars < 20) {
                $words .= $ones[$dollars];
            } else {
                $tens_digit = floor($dollars / 10);
                $ones_digit = $dollars % 10;
                $words .= $tens[$tens_digit] . ' ' . $ones[$ones_digit];
            }
        }

        // $words .= ' dollar';
        if ($dollars != 1) {
            // $words .= 's';
        }
    }

    if ($cents > 0) {
        $words .= ' and ';
        if ($cents < 20) {
            $words .= $ones[$cents];
        } else {
            $tens_digit = floor($cents / 10);
            $ones_digit = $cents % 10;
            $words .= $tens[$tens_digit] . ' ' . $ones[$ones_digit];
        }
        $words .= ' cent';
        if ($cents != 1) {
            // $words .= 's';
        }
    }

    return $words;
}
?>

</html>
<script>
    document.getElementById("gst").addEventListener("change", function() {
    document.getElementById("market_gst").textContent = this.value;
});

    </script>