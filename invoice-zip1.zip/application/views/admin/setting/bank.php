<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
<?php echo form_open('admin/bankd') ?>
<div class="card-body">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-6">
                    <label>Bank Name :</label>
                    <input type="text" class="form-control form-control-alternative"  name="bank">
                    </div>
                    <div class="col-sm-6">
                    <label>account Number : </label>
                    <input class="form-control form-control-alternative"  name="account">
                  </div>
                  <div class="col-sm-6 mt-3">
                    <label>Ifsc Code :</label>
                    <input class="form-control form-control-alternative" name="ifsc">
                  </div>
                  <div class="col-sm-6 mt-3">
                    <label>Bank Branch :</label>
                    <input class="form-control form-control-alternative" name="branch">
                  </div>
                  <div class="col-sm-6 mt-3">
                    <label>Account Holder Name :</label>
                    <input class="form-control form-control-alternative" name="holder">
                  </div>
                  <!-- <div class="col-sm-6 mt-3">
                    <label>Swift Code :</label>
                    <input class="form-control form-control-alternative" name="swift">
                  </div> -->
                  <div class="col-sm-6 mt-3">
                    <input type="submit" class="btn btn-success" value="Add bank"  onclick="this.value='Adding..'">
                  </div>
          </div>
       </div>
</div>
<?php echo form_close() ?>
    <div class="table-responsive">
    <table class="table table-striped table-bordered">
        <tr>
            <th>SN</th>
            <th>Bank Name</th>
            <th>Account Holder</th>
            <th>Account </th>
            <th>IFSC </th>
            <th>Branch </th>
            
            <th>Actions</th>
        </tr>
        <?php
            $sn = 1;
            foreach ($data as $e) { 
        ?>
            <tr>
                <td><?php echo $sn++; ?></td>
                <td><?php echo $e['name']; ?></td>
                <td><?php echo $e['holder']; ?></td>
                <td><?php echo $e['account']; ?></td>
                <td><?php echo $e['ifsc']; ?></td>
                <td><?php echo $e['branch']; ?></td>
               
                <td>
                    <a  href="<?php echo site_url('admin/fbank_edit/' . $e['id']); ?>" class="btn btn-primary btn-sm">Edit</a>
                    <a onclick="return confirm('Are you sure you want to delete this Bank ?')" href="<?php echo site_url('admin/fbank_remove/' . $e['id']); ?>" class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
        <?php } ?>
    </table>
    <div class="pull-right">
        <?php echo $this->pagination->create_links(); ?>
    </div>
</div>
</div>
</div>
