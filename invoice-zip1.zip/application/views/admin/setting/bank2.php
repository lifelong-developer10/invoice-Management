<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
<?php echo form_open('admin/bankd') ?>
<div class="card-body">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-6">
                    <label>Bank Name :</label>
                    <input type="text" class="form-control form-control-alternative"  name="bank" value="<?php echo $data->name ?>">
                    </div>
                    <div class="col-sm-6">
                    <label>account Number : </label>
                    <input class="form-control form-control-alternative"  name="account" value="<?php echo $data->account ?>">
                  </div>
                  <div class="col-sm-6 mt-3">
                    <label>Ifsc Code :</label>
                    <input class="form-control form-control-alternative" name="ifsc" value="<?php echo $data->ifsc ?>">
                  </div>
                  <div class="col-sm-6 mt-3">
                    <label>Bank Branch :</label>
                    <input class="form-control form-control-alternative" name="branch" value="<?php echo $data->branch ?>">
                  </div>
                  <div class="col-sm-6 mt-3">
                    <label>Account Holder Name :</label>
                    <input class="form-control form-control-alternative" name="holder" value="<?php echo $data->holder ?>">
                  </div>
                  <div class="col-sm-6 mt-3">
      
                    <input class="form-control form-control-alternative" name="typee" value="update" type="hidden">
                    <input class="form-control form-control-alternative" name="id" value="<?php echo $data->id ?>" type="hidden">
                  </div>
                  <div class="col-sm-6 mt-3">
                    <input type="submit" class="btn btn-success" value="Edit bank"  onclick="this.value='Updating..'">
                  </div>
          </div>
       </div>
</div>
</div>
</div>
<?php echo form_close() ?>
