<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
<?php echo form_open('admin/customerd') ?>
<div class="card-body">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-6">
                    <label>Customer Name :</label>
                    <input type="text" class="form-control form-control-alternative"  name="name" value="<?php echo $data->name ?>">
                    </div>
                    <!-- <div class="col-sm-6">
                    <label>Company Name : </label>
                    <input type="text" class="form-control form-control-alternative"  name="cname" value="<?php echo $data->cname ?>">
                  </div> -->
                  <!-- <div class="col-sm-6 mt-3">
                    <label>Vat Number :</label>
                    <input type="text" class="form-control form-control-alternative" name="vat" value="<?php echo $data->vat ?>">
                  </div> -->
                  <div class="col-sm-6 mt-3">
                    <label>Contact Number :</label>
                    <input type="text" class="form-control form-control-alternative" name="phone" value="<?php echo $data->phone ?>">
                  </div>
                  <div class="col-sm-6 mt-3">
                    <label>Address :</label>
                    <input type="text" class="form-control form-control-alternative" name="add" value="<?php echo $data->address ?>">
                  </div>
                  <div class="col-sm-6 mt-3">
                    <label>Email :</label>
                    <input type="text" class="form-control form-control-alternative" name="email" value="<?php echo $data->email ?>">
                    <input type="hidden" class="form-control form-control-alternative" name="id" value="<?php echo $data->id ?>">
                    <input class="form-control form-control-alternative" name="typee" value="update" type="hidden">
                  </div>
                  <div class="col-sm-6 mt-3">
                    <input type="submit" class="btn btn-success" value="Edit Customer"  onclick="this.value='Updating..'">
                  </div>
          </div>
       </div>
</div>
</div>
</div>
<?php echo form_close() ?>
