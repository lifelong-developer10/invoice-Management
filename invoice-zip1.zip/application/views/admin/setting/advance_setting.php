
<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
<?php echo form_open() ?>
<div class="card-body">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-6">
                    <label>Company Name</label>
                    <input type="text" class="form-control form-control-alternative" value="<?php echo set_value('company_name', config_item('company_name')) ?>" name="company_name">
                    </div>
                    <div class="col-sm-6">
                    <label>Company Address</label>
                    <input class="form-control form-control-alternative" value="<?php echo set_value('company_address', config_item('company_address')) ?>"
                        name="company_address">
                  </div>
                  <div class="col-sm-6">
                    <label>Company Account Number</label>
                    <input class="form-control form-control-alternative" value="<?php echo set_value('account_number', config_item('account_number')) ?>"
                        name="account_number">
                  </div>
                  <div class="col-sm-6">
                    <label>IFSC Code</label>
                    <input class="form-control form-control-alternative" value="<?php echo set_value('ifsc_Code', config_item('ifsc_Code')) ?>"
                        name="ifsc_Code">
                  </div>
                  <div class="col-sm-6">
                    <label>Bank Branch</label>
                    <input class="form-control form-control-alternative" value="<?php echo set_value('bank_branch', config_item('bank_branch')) ?>"
                        name="bank_branch">
                  </div>
                  <div class="col-sm-6">
                    <label>Account Name</label>
                    <input class="form-control form-control-alternative" value="<?php echo set_value('account_name', config_item('account_name')) ?>"
                        name="account_name">
                  </div>
          </div>
       </div>
  
 <div class="card-footer">
        <div class="row">   
            <div class="col-6">
                <label>Secret Password</label> (This is not admin password)
                <input type="password" class="form-control form-control-alternative" name="dev_pass">
            </div>
        <div class="col-sm-4"><br/>
                <input type="submit" class="btn btn-success" value="Update"  onclick="this.value='Updating..'">
        </div>
    </div>
</div>
<?php echo form_close() ?>
</div>
</div>
