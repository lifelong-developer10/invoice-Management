<?php
 
$this->load->config('email'); 
?>
<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
<?php echo form_open_multipart() ?>
<div class="card-body">
                <div class="row">
                    <div class="col-sm-6">
                    <label>Company Name</label>
                    <input type="text" class="form-control form-control-alternative" value="" name="company_name">
                    </div>
                    <div class="col-sm-6">
                    <label>GSTIN NO</label>
                    <input type="text" class="form-control form-control-alternative" value="" name="gst_id">
                    </div>
                    <div class="col-sm-6">
                    <label>Company Address</label>
                    <input type="text" class="form-control form-control-alternative" value="" name="address">
                    </div>
                    <div class="col-sm-6">
                    <label>Contact NO:</label>
                    <input class="form-control form-control-alternative" value="" name="contact">
                  </div>
                  <div class="col-sm-6">
                    <label>Email</label>
                    <input class="form-control form-control-alternative" value="" name="email">
                  </div>
                  <div class="col-sm-5 mt-4">
                    
                    <input type="file" class="custom-file-input" name="logo" id="logo"
                      aria-describedby="inputGroupFileAddon01">
                    <label class="custom-file-label" for="logo">Choose logo</label>
                  
            </div>
            <div class="col-sm-4"><br/>
                <input type="submit" class="btn btn-success" value="Update"  onclick="this.value='Updating..'">
        </div>
          </div>
       </div>
</div>
<?php echo form_close() ?>
</div>
</div>
