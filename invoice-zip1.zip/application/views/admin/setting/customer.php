
<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
<?php echo form_open('admin/customerd') ?>
<div class="card-body">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-6">
                    <label>Customer Name :</label>
                    <input type="text" class="form-control form-control-alternative"  name="name">
                    </div>
                    <!-- <div class="col-sm-6">
                    <label>Company Name  : </label>
                    <input class="form-control form-control-alternative"  name="cname">
                  </div> -->
                  <!-- <div class="col-sm-6 mt-3">
                    <label>Vat Number :</label>
                    <input class="form-control form-control-alternative" name="vat">
                  </div> -->
                  <div class="col-sm-6 mt-3">
                    <label>Contact Number :</label>
                    <input class="form-control form-control-alternative" name="phone">
                  </div>
                  <div class="col-sm-6 mt-3">
                    <label>Address :</label>
                    <input class="form-control form-control-alternative" name="add">
                  </div>
                  <div class="col-sm-6 mt-3">
                    <label>Email :</label>
                    <input class="form-control form-control-alternative" name="email">
                  </div>
                  <div class="col-sm-6 mt-3">
                    <input type="submit" class="btn btn-success" value="Add Customer"  onclick="this.value='Adding..'">
                  </div>
          </div>
       </div>
</div>
<?php echo form_close() ?>
    <div class="table-responsive">
    <table class="table table-striped table-bordered" id="example">
        <tr>
            <th>SN</th>
            <th>Customer Name</th>
            <th>Phone Number </th>
            <th>Email </th>
            <th>Address </th>
            <th>Actions</th>
        </tr>
        <?php
            $sn = 1;
            foreach ($data as $e) { 
        ?>
            <tr>
                <td><?php echo $sn++; ?></td>
                <td><?php echo $e['name']; ?></td>
                <td><?php echo $e['phone']; ?></td>
                <td><?php echo $e['email']; ?></td>
                <td><?php echo $e['address']; ?></td>
                <td>
                    <a  href="<?php echo site_url('admin/customer_edit/' . $e['id']); ?>" class="btn btn-primary btn-sm">Edit</a>
                    <a onclick="return confirm('Are you sure you want to delete this Bank ?')" href="<?php echo site_url('admin/customer_remove/' . $e['id']); ?>" class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
        <?php } ?>
    </table>
</div>
</div>
</div>
