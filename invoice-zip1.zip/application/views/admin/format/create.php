<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>

<div class="card-body">
    <?php echo form_open_multipart('admin/saveFormats') ?>
    <div class="form-group">
       <div class="card" style="background-color: #f7fafc;">
          <div class="card-header"> Format Information</div>
            <div class="card-body">
            <div class="row">
    <div class="col-sm-12 mt-2">
        <label class="prolabel">Format Name</label>
        <input type="text" class="form-control form-control-alternative" name="format_name" value="">
    </div>
</div>
<div class="row">
    <div class="col-12 mt-2">
        <label class="prolabel">Formats</label>
        <div class="checkbox-group row">
            <?php foreach ($data as $item) { ?>
     
                <div class="checkbox col-3">
                    <label>
                        <input type="checkbox" name="formats[]" value="<?php echo $item['name']; ?>">&nbsp;&nbsp;<?php echo $item['label']; ?>
                    </label>
                </div>
            <?php } ?>            
            <input type="hidden" name="labels[]" value="">
            <input type="hidden" name="columnss[]" value="">
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $(document).ready(function() {
    var selectedLabels = [];

    $('input[type="checkbox"]').change(function() {
      var label = $(this).closest('.checkbox').find('label').text().trim();
      
      if ($(this).is(':checked')) {
        selectedLabels.push(label);
      } else {
        var index = selectedLabels.indexOf(label);
        if (index > -1) {
          selectedLabels.splice(index, 1);
        }
      }

      $('input[name="labels[]"]').val(selectedLabels.join(', '));
    });
  });
</script>
<script>
$(document).ready(function() {
  var selectedLabels = [];
  var selectedColumns = [];

  $('input[type="checkbox"]').change(function() {
    var label = $(this).closest('.checkbox').find('label').text().trim();
    var columnValue = $(this).val();

    if ($(this).is(':checked')) {
      selectedLabels.push(label);
      selectedColumns.push(columnValue);
    } else {
      var labelIndex = selectedLabels.indexOf(label);
      if (labelIndex > -1) {
        selectedLabels.splice(labelIndex, 1);
        selectedColumns.splice(labelIndex, 1);
      }
    }
    var reversedLabels = selectedLabels.slice().reverse(); 
    $('input[name="columnss[]"]').val(selectedColumns.join(', '));
  });
});
</script>


            </div>
        </div>
        <br>
        <input type="submit" class="btn btn-success pull-right" value="Create " onclick="this.value='Creating..'">
        </div>
    </div>
    <?php echo form_close() ?>
</div>
</div>
