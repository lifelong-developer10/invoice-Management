
<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
   

    <div class="table-responsive">
    <table class="table table-striped table-bordered">
        <tr>
            <th>SN</th>
            <th>Format Name</th>
            <th>Columns </th>
            <th>Actions</th>
        </tr>
        <?php
            $sn = 1;
            foreach ($data as $e) { 
                $formatString = $e['labels'];
                $selectedFormats = explode(', ', $formatString);
        ?>
            <tr>
                <td><?php echo $sn++; ?></td>
                <td><?php echo $e['name']; ?></td>
                <td>
                    <?php 
                        foreach ($selectedFormats as $format) {
                            echo $format . '<br>';
                        }
                    ?>
                </td>
                <td>
                    <a onclick="return confirm('Are you sure you want to delete this Category ?')"
                       href="<?php echo site_url('admin/format_remove/' . $e['id']); ?>"
                       class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
        <?php } ?>
    </table>
    <div class="pull-right">
        <?php echo $this->pagination->create_links(); ?>
    </div>
</div>
</div>
</div>
