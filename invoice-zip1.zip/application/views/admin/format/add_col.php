
<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
    <?php echo form_open_multipart('admin/column_add') ?>
    <div class="row border p-3 m-3">
        <div class="col-12">
            <span><h2 class="text-center">Add New Column</h2></span>
        </div>
        <div class="col-sm-12">
            <label class="prolabel">Column Name : </label> 
            <input type="text" class="form-control form-control-alternative" name="ColName" value="" pattern="[a-zA-Z0-9_]+" title="Only alphanumeric characters and underscores are allowed" required>
        </div>
        <div class="col-sm-12 mt-3">
            <label class="prolabel">Label Name : </label> 
            <input type="text" class="form-control form-control-alternative" name="label" value="" required>
        </div>
        <div class="col-sm-12 mt-4">
            <input type="submit" class="btn btn-success pull-right" value="Add Column" onclick="this.value='Adding..'">
        </div>
    </div>
    <?php echo form_close() ?>
    <div class="table-responsive">
    <table class="table table-striped table-bordered">
        <tr>
            <th>SN</th>
            <th>Column Name</th>
            <th>Label Name</th>
            <th>Actions</th>
        </tr>
        <?php
            $sn = 1;
            foreach ($data as $e) { 
        ?>
            <tr>
                <td><?php echo $sn++; ?></td>
                <td><?php echo $e['name']; ?></td>
                <td><?php echo $e['label']; ?></td>
                <td>
                    <a onclick="return confirm('Are you sure you want to delete this Column ?')"
                       href="<?php echo site_url('admin/column_remove/' . $e['id']); ?>"
                       class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
        <?php } ?>
    </table>
    <div class="pull-right">
        <?php echo $this->pagination->create_links(); ?>
    </div>
</div>
</div>
</div>
