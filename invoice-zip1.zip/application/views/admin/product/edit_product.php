<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
<div class="card-body">
     
        <?php echo form_open_multipart() ?>
        <div class="form-group">
            <div class="row">
                    <div class="col-sm-12 mt-2">
                        <label>Service Name</label>
                        <input type="text" class="form-control" name="prod_name" value="<?php echo set_value('prod_name', $data->prod_name) ?>">
                    </div>
                    <input type="hidden" name="id" value="<?php echo $data->id ?>">
                    <input type="hidden" name="image" value="<?php echo $data->image ?>">
                    <div class="col-sm-12 mt-2">
                        <label>Service Category</label>
                        <select class="form-control" name="category">
                            <option selected value="<?php $category = set_value('category', $data->category);
                            echo $category ?>"><?php echo $this->db_model->select('cat_name', 'product_categories', array('id' => $category)) ?></option>
                            <?php foreach ($parents as $val) {
                                echo '<option value="' . $val['id'] . '">' . $val['cat_name'] . '</option>';
                            } ?>
                        </select>
                    </div>
            </div>
            <div class="row">
                <div class="col-sm-12 mt-2">
                    <label>Service Description</label>
                    <textarea class="form-control" id="editor" name="prod_desc"><?php echo set_value('prod_desc', $data->prod_desc) ?></textarea>
                </div>
                <div class="col-sm-12 mt-2">
                    <label>Service Price In INR </label>
                    <input type="text" class="form-control" name="prod_price" value="<?php echo set_value('prod_price', $data->prod_price) ?>">
                </div>
            </div> 
            <input type="submit" class="btn btn-success  mt-4" value="Update" onclick="this.value='Updating..'">
</div>
<?php echo form_close() ?>

</div>

