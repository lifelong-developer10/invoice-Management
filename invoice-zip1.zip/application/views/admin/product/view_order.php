<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
<div class="card-body">
<div class="table-responsive">
                <table class="table align-items-center table-flush">
                   <thead class="thead-light">
        <tr style="font-weight: bold">
            <td>Product Name</td>
            <td>User id</td>
            <td>Customer Name</td>
            <td>Qty</td>
            <td>Order Date</td>
            <td>Status</td>
            <td>Total Cost</td>
        </tr>
    </thead>
        <tr>
            <td><?php echo $this->db_model->select('prod_name', 'product', array('id' => $orders->product_id)); ?></td>
            <td><?php echo $orders->userid;?></td>
            <td><?php echo $this->db_model->select('name', 'member', array('id' => $orders->userid));?></td>
            <td><?php echo $orders->qty ?></td>
            <td><?php echo $orders->date ?></td>
            <td><?php 
                    echo $orders->status 
                ?></td>
            <td><?php echo config_item('currency') . ($orders->cost * $orders->qty) ?></td>
        </tr>
    </table>
</div>
</div>
<div class="card-footer">
    <a href="javascript:history.back()" class="btn btn-sm btn-primary">Go Back</a>
</div>
</div>
</div>
