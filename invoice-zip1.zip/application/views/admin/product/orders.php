<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>
</div> 
<div class="card-body">
            
   <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
        <tr>
            <th scope="col">SN</th>
            <th scope="col">User ID</th>
            <th scope="col">Full Name</th>
            <th scope="col">Product</th>
            <th scope="col">Product Cost</th>
            <th scope="col">Cost</th>
            <th scope="col">Qty</th>
            <th scope="col">Oreder id</th>
            <th scope="col">Order Date</th>
            <th scope="col">Status</th>
            <th scope="col">Action</th>
        </tr>
    </thead> 
        <?php  
     
        $sn = 1;
        foreach ($orders as $e) { 
              $this->db->select('product_id')->from('product_sale')->where(array('id' => $e->id));
                                             $p_id = $this->db->get()->result();

          ?>
            <tr>
                <td><?php echo $sn++; ?></td>
                <td><?php echo config_item('ID_EXT') . $e->userid; ?></td>
                <td><?php echo $this->db_model->select('name', 'member', array('id' => $e->userid)); ?></td>
                 <td><?php
                     foreach ($p_id as $p)
                     {
                        $p_name  = $this->db_model->select('prod_name', 'product', array('id' => $p->product_id));
                        echo $p_name;
                        echo "<br>";
                    }
                    ?>
                </td>
               
           <!--      <td><?php echo $this->db_model->select('prod_name', 'product', array('id' => $e->product_id)); ?></td> -->
           <td> <?php
                     foreach ($p_id as $p)
                     {
                        $price  = $this->db_model->select('dealer_price', 'product', array('id' => $p->product_id));
                       // $this->db->select('prod_name')->from('product')->where(array('id' => $p->product_id));
                       //$p_name = $this->db->get()->result();
                        echo config_item('currency') .$price;
                        echo "<br>";
                    }
                    ?></td>
                <td><?php echo config_item('currency') . $e->cost; ?></td>  
                <td>
                <?php
                     foreach ($p_id as $p)
                     {
                        $qty  = $this->db_model->select('qty', 'product_sale', array('id' => $p->product_id));
                        echo $qty;
                        echo "<br>";
                    }
                    ?>
               <!--  <?php echo $this->db_model->select('qty', 'product_sale', array('id' => $e->product_id)); ?> -->
                    
                </td>
                <!-- <td><?php echo $e->qty;?></td> -->
                <td><?php echo $e->orderid;?></td>
                <td><?php echo $e->date; ?></td> 
              <td><?php echo $e->status; ?></td>  
                <td>
                    <div class="dropdown">
                        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="fas fa-ellipsis-v"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                           <?php if ($e->status !== "Completed") { ?>
                             <a class="dropdown-item" data-toggle="modal" data-target="#myModal"
                            onclick="document.getElementById('deliverid').value='<?php echo $e->orderid ?>'"
                           >Deliver</a>
                            <?php } ?>
                            <a class="dropdown-item" href="<?php echo site_url('product/view_order/' . $e->id); ?>"
                               >View</a>
                            <a class="dropdown-item" onclick="return confirm('Are you sure you want to delete this Order ?')"
                               href="<?php echo site_url('product/remove_order/' . $e->id); ?>" >Delete</a>

                        </div>
                    </div> 
                </td>
               
            </tr>
        <?php } ?>
    </table>
    <div class="pull-right">
        <?php echo $this->pagination->create_links(); ?>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delivery Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
       <?php echo form_open('product/deliver') ?>
      <div class="modal-body">
       
                <label>Enter Delivery Detail (eg: Tracking No)</label>
                <input type="hidden" name="deliverid" value="" id="deliverid">
                <textarea class="form-control" name="tdetail"></textarea>
                   
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
         <button type="submit" class="btn btn-sm btn-success">Deliver Now</button>
      </div>

      <?php echo form_close() ?>
    </div>
  </div>
</div>



</div>
</div>
</div>