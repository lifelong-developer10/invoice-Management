<div class="col">
    <div class="card bg-secondary shadow">  
        <div class="card-header bg-white border-0"> 
        <div class="row align-items-center">
            <div class="col-8">
                  <h3 class="mb-0"><?php echo $title;?></h3>
            </div>
        <div class="col-4 text-right"> 
            <a href="<?php echo site_url('admin/index')?>" class="btn btn-sm btn-primary">Home</a>
        </div>
    </div>

<div class="card-body">
    <?php echo form_open_multipart() ?>
    <div class="form-group">
       <div class="card" style="background-color: #f7fafc;">
          <div class="card-header"> Services Information</div>
            <div class="card-body">
                <div class="row">
                <div class="col-sm-12 mt-2">
                    <label class="prolabel">Service Name</label>
                    <input type="text" class="form-control form-control-alternative" name="prod_name" value="<?php echo set_value('prod_name') ?>">
                </div>
                <div class="col-sm-12 mt-2">
                    <label class="prolabel">Service Price in INR</label>
                    <input type="text" class="form-control form-control-alternative" name="prod_price" value="<?php echo set_value('prod_name') ?>">
                </div>
                <div class="col-sm-12 mt-2">
                    <label class="prolabel">Service Category</label>
                    <select class="form-control form-control-alternative" name="category">
                        <?php foreach ($parents as $val) {
                            echo '<option value="' . $val['id'] . '">' . $val['cat_name'] . '</option>';
                        } ?>
                    </select>
                </div>
                  <div class="col-sm-12 mt-2">
                        <label class="prolabel">Service Description</label>
                        <textarea class="form-control form-control-alternative" id="editor" name="prod_desc"><?php echo set_value('prod_desc') ?></textarea>
                    </div>
                </div> 
            </div>
        </div>
        <br>
        <input type="submit" class="btn btn-success pull-right" value="Create " onclick="this.value='Creating..'">
        </div>
    </div>
    <?php echo form_close() ?>
</div>
</div>
