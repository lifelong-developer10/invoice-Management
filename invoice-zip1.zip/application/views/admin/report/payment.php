  <div class="col">
          <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
              <h3 class="mb-0"><?php echo $title ?></h3>
            </div>
            <!-- Light table -->
            <div class="table-responsive">
            <div class="pl-lg-4 m-2">
              <table id="example" class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col" class="sort" data-sort="name">SN</th>
                    <th scope="col" class="sort" data-sort="name">Invoice Number</th>
                    <th scope="col" class="sort" data-sort="name">Company Name</th>
                    <th scope="col" class="sort" data-sort="name">Total Amount</th>
                    <th scope="col" class="sort" data-sort="name">Paid Amount</th>
                    <th scope="col" class="sort" data-sort="name">Balance Amount</th>
                    <th scope="col" class="sort" data-sort="name">Status</th>
                    <th scope="col" class="sort" data-sort="name">Date</th>
                  </tr>
                </thead>
                <tbody class="list">
                <?php
                    $sn = 1;
                    foreach ($data as $e) { 
                ?>
                <tr> 
                  <td scope="row"><img alt="Photo" src="<?php echo base_url('uploads/logo.png')?>" class="avatar rounded-circle mr-3"/><?php echo $sn++; ?></td>
                  <td scope="row"><a href="<?php echo site_url('accounting/invoice_view/' . $e['id']); ?>" target="_blank"><?php echo $e['invoice_name']; ?></a></td>
                  <td scope="row"><?php echo $e['company_name'] ?></td>
                  <td scope="row" class="text-info"><?php echo $e['total_amt'] ?></td>
                  <td scope="row" class="text-warning"><?php echo $e['paid_amt'] ?></td>
                  <td scope="row" class="text-danger">
                      <?php 
                        $balnce = $e['total_amt'] - $e['paid_amt'];
                        if($balnce <= 0){
                            echo "<span class='text-success'>NILL</span>";
                            $txt = 'Paid';
                            $clr = 'success';
                        }
                        else{
                            echo "<span class='text-danger'>".$balnce."</span>";
                            $txt = 'UnPaid';
                            $clr = 'danger';
                        }
                      ?>
                  </td>
                  <td scope="row"><span class="btn btn-<?php echo $clr ?>  btn-sm"><?php echo $txt ?></span></td>
                  <td scope="row"><?php echo $e['date'] ?></td>
                </tr>
                <?php } ?>
                </tbody>
              </table>
            </div>
            <!-- Card footer --> 
          </div>
