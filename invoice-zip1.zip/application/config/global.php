<?php
        defined('BASEPATH') OR exit('Can we play bubu together ?');

        $config['company_name'] = "Speed Marine";
        $config['company_address'] = "pune";
        $config['ID_EXT'] = ''; # ID Extension eg: DM1001
        $config['currency'] = " "; # Sitewide currency
        $config['iso_currency'] = " "; # ISO Code of currency
        $config['leg'] = ""; # 1, 2, 3, 4, 5(eg: for binary plan leg is 2)
        $config['show_leg_choose'] = ""; ## Whether to show placement ID box at registration
        $config['show_placement_id'] = ""; ## Whether to show select position option or not
        $config['autopool_registration'] = "";
        $config['show_join_product'] = "";
        $config['enable_epin'] = "";
        $config['enable_pg'] = ""; # Payment Gateway
        $config['free_registration'] = "";
        $config['sms_on_join'] = "";
        $config['top_id'] = "1001";
        $config['prevent_join_product_entry'] = "";
        $config['enable_gap_commission'] = "";
        $config['sms_api'] = "";
        ## Format: https://apiurl.com?no={{phone}}&msg={{msg}}&other_parameters.
        $config['disable_registration'] = "";
        $config['fix_income'] = "";
        $config['task_based'] = "";
        $config['auto_payout'] = "";
        $config['account_number'] = "357002000000082";
        $config['ifsc_Code'] = "IOBA0003570";
        $config['bank_branch'] = "Pune";
        $config['account_name'] = "admin";
        $config['give_income_on_topup'] = "";
        ####################### MODULE SETTING ############################## 
        $config['enable_topup'] = "";
        $config['enable_repurchase'] = "";
        $config['enable_coupon'] = "";
        $config['enable_ad_incm'] = "";
        $config['enable_survey'] = "";
        $config['enable_recharge'] = "";
        $config['enable_reward'] = "";
        $config['enable_help_plan'] = "";
        $config['enable_product'] = "";
        $config['member_theme']='';
        $config['enable_upgrade']='';
        $config['investment_mode'] = ""; ## AUTO, EPIN, MANUAL
        
        $config['cron_minutes'] = ""; 
        $config['cron_hours'] = ""; 
        $config['cron_day'] = ""; 
        $config['cron_month'] = ""; 
        $config['cron_weekday'] = ""; 
        
        
        $config['enable_investment'] = ""; ## This will convert existing software to a investment plan software and will turn off many features.