<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['google_client_id']="8584371115-jboo35s76h18n08n8jmsdn2qjikfjaf5.apps.googleusercontent.com";
$config['google_client_secret']="iHJLELXRo2Wh7JYbNypWy4he";
$config['google_redirect_url']='http://localhost/';  

