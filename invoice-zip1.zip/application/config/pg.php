<?php
defined('BASEPATH') OR exit('Can we play bubu together ?');

$config['enable_paypal'] = "";
$config['paypal_email'] = "axolotlsindia@gmail.com";
$config['paypal_currency'] = "INR";

$config['enable_instamojo'] = "";
$config['instamojo_api_key'] = "6802cf1bb989d196a1dd42b363c102ef";
$config['instamojo_auth'] = "8ce9b1ea223e53661dc18a49bcab7eda";
$config['instamojo_salt'] = "d386c3899d0646ec8c38bdd6ed9a54a5";

$config['payumoney_key'] = "uM7qP5";
$config['payumoney_salt'] = "k2MKtVXM";

$config['enable_paytm'] = "";
$config['PAYTM_MERCHANT_KEY'] = "sdduasdfkdasfl";
$config['PAYTM_MERCHANT_MID'] = "34532432423423";


$config['RAZOR_KEY_ID'] = "rzp_test_R1eidjLvE7H1Vt";
$config['RAZOR_KEY_SECRET'] = "nEE1AOVGu476ZkJ3jauqF0XE";


$config['enable_block_io'] = "";
$config['api_key'] = "";
$config['secret_pin'] = "";
 