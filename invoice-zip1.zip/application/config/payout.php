<?php
            defined('BASEPATH') OR exit('Can we play bubu together ?');

            $config['payout_tax'] = "5";
             $config['payout_tax2'] = "5";
            $config['admin_charges'] = "5";
            $config['user_withdraw'] = "Yes";
            $config['min_withdraw'] = "100"; 
            $config['wallet_type'] = "No";#This is for seperate wallet
            $config['payment_api'] = "None"; #What gateway to use for auto payment
            $config['gen_list']="Yes";#enable generations
            $config['auto_debit']="0";#Auto debit
            $config['rank_bonus']="No";
            $config['percentage']="55";
            