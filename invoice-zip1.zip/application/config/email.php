<?php


                // Email Setting Start

                $config['protocol'] = 'smtp';
                $config['smtp_crypto'] = 'ssl';
                $config['mailtype'] = 'html';
                $config['wtrans'] = '';
            