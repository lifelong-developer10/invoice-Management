<?php
            defined('BASEPATH') OR exit('Can we play bubu together ?');

            $config['plantype'] = "Binary ROI";
           
            